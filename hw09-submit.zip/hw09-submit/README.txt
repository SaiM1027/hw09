=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=
CIS 120 Game Project README
PennKey: mamidala
=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=

===================
=: Core Concepts :=
===================

- List the four core concepts, the features they implement, and why each feature
  is an appropriate use of the concept. Incorporate the feedback you got after
  submitting your proposal.

  1. File I/O is used to save the game state when it is paused or ends and also to load it upon reopening. 
  For example, in DefaultWorldLoader.java, I've created a method pathToDir which sets a path to the user's directory 
  on their machine where the game state is recorded. I also used BufferedReader which reads from the saved file upon 
  loading the game. Also in DefaultWorldLoader.java I have imported PrintWriter which uses Buffered Reader; this prints
  various properties about the game and game entities' states to the save file (a text file set by the user directory.

  2. Inheritance was used in the implementation of EntityBlueprint. EntityBlueprint is an abstract class that set texture,
  speed, and health for various entities in the game including tree stumps, fires, lamps, fire spray, trees, and
  the player itself. Due to the differing requirements and behaviors of each of these types of entities, the abstract
  methods in the EntityBlueprint class are implemented differently in each of the classes that use it, such as Fire.java,
  Tree.java, and many more. For example, the person moves differently than the fire extinguishing spray, and these 
  differences are reflected in each class's calculations.

  3. 2D Arrays were used in Texture.java for building the world tile by tile and putting specific textures onto each tile. 
  For example, the asphalt, grass, trees, etc were all different types of textures that had to be read into a 2D array to 
  actually display it on the plain tiles that were the foundation of the world. The tiles themselves are in World.java, and 
  it contains an array of Block objects which each hold a certain texture. In addition, the brightness of these tiles is also
  variable because of the lamps, so this functionality is also initialized through 3 2D arrays (for R, G, and B) in World.java.

  4. Collections are used in this project in the form of ArrayLists and a (rudimentary) HashMap. The ArrayList is of all things
  that have a texture in the game that will get drawn to the screen. I used the sort() method in World.java to sort entities from 
  back to front, so that they get rendered similarly to the Painter's Algorithm (things in the background first, things in the 
  foreground last.) 2 HashMaps are used in WorldGenHelper.java, one to map little strings to the blocks that make up the world and 
  another to map little strings to various entities in the game. This is useful when saving a world file and all entity types/positions 
  have to turn an EntityBlueprint into Strings in order to save it in a text file which then is saved in the user's directory.
  


=========================
=: Your Implementation :=
=========================

- Provide an overview of each of the classes in your code, and what their
  function is in the overall game.
  GameO.java: abstract. the programmer extends this class to make their driver
  Input.java: put all the inputs (mouse/key listeners) in one simple class-- has static methods 
  Main.java: called by the driver class when the programmer wants to start the game
  Render.java: contains the JFrame, clears the screen, renders blocks and entities
  Tick.java: helps keep track of current state, helps time animations
  Asphalt.java: extends BlockBlueprint and is a model for the asphalt block
  Block.java: source for all block objects, implements BlockBlueprint's methods, sets number of pixels
  BlockBlueprint.java: abstract. Makes sure each block has a texture as this is what defines the block
  Bricks.java: just a brick texture
  Dirt.java: a dirt texture, similar to Bricks.java, use this object whenever we want to create a dirt block
  Grass.java: a grass texture, use this in the Block constructor to create grass blocks 
  Pavement.java: a pavement texture, use this in the Block constructor to create pavement blocks
  RoadHor.java: horizontal road texture, use this to create horizontal roads
  RoadVer.java: vertical road texture
  Stone.java: stone texture, similar to Bricks
  DeadStump.java: dead tree stump objects can be created from this class, can check if tree is actually dead from checking surrounding blocks
  Entity.java: has an EntityBlueprint, health, birthdate, and have some movement element, has getter methods for screen coordinates, health management, death, etc
  EntityBlueprint.java: abstract. lists attributes that can be given to an entity such as texture, speed, health and brightness
  Fire.java: extends EntityBlueprint, chooses texture, has methods for birth of a fire, death of a fire (when it's hit with the fire extinguisher), and manages reward when fire is killed
  Giant.java: didn't have time to fully implement this, ignore
  Lamp.java: extends EntityBlueprint, creates a light, removes it, makes sure it doesn't move
  Lamppost.java: extends EntityBlueprint, holds the lamp and has much the same behavior
  Light.java: represents a Light that can be used by the World to light areas up
  Player.java: extends EntityBlueprint, the player that appears in the middle of the screen, contains calculations for movement, establishes no special behavior for birth/death, chooses texture
  Spray.java: extends EntityBlueprint, fire extinguisher that is spawned from the player, if the fire is in a certain "HitBox" then it is put out. the spray has a certain trajectory it follows
  Tree.java: extends EntityBlueprint, randomly spawns baby trees and makes sure trees don't live forever, plans birth and death of trees, chooses texture
  TreeBurnFull.java: extends EntityBlueprint, same as above except the tree is burned
  TreeBurnHalf.java: extends EntityBlueprint, same as above except the tree is half burned
  TreeSapling.java: extends EntityBlueprint, 'grows' into a tree (is replaced by a full tree, but can still die)
  TreeStump.java: extends EntityBlueprint, randomly decides whether or not to spawn a new sapling upon death
  Zombie.java: randomly sometimes a giant zombie will come towards the player
  Inventory.java: didn't have time to fully implement this, ignore
  ItemManager.java: didn't have time to fully implement this, ignore
  ItemType.java: didn't have time to fully implement this, ignore
  Metal.java: didn't have time to fully implement this, ignore
  Weapon.java: didn't have time to fully implement this, ignore
  Wood.java: didn't have time to fully implement this, ignore
  Frame.java: initializes JFrame, add mouse/mouse motion/key listeners, accesses canvas through frame object, draws textures according to Painter's Algorithm
  GCanvas.java: what actually gets drawn to the screen (pixel by pixel)
  Texture.java: hard code of each texture (asphalt, etc plus all the buttons)
  TextureAtlas.java: loads an image file that contains several textures next to each other
  Textured.java: interface. a texture and screen coordinates, which is enough information to get rendered to the screen
  Button.java: abstract. implements Textured and has a bunch of getter methods for x, y, texture, and hovering behavior
  MenuSetup.java: place to handle all the buttons in a menu basically the intro screen
  World.java: establishes tiles 2d array, block dims, rendering perspective, list of entities, has methods for lighting calculations to add or remove light intensity to each of the three color channels
  WorldGenerator.java: classes that implement this interface may be used by the World class to generate worlds
  DefaultWorldLoader.java: uses BufferedReader to save/load game files, initializes world full of grass and then creates forest areas and places lamps and brick/road/etc placement, reads entities
  Game.java: starts the game and runs help menu, main menu etc loops at consistent intervals
  HeartDrawer.java: manages losing/gaining of lives
  WorldGenHelper.java: uses hardcoded HashMaps to map strings and blocks/entities to make the game state easier to save in a text file
  BoundsChecker.java: private. makes sure a pixel's coordinates are actually on the screen
  Vector2f.java: plain vector calculations later used in fire extinguisher behavior

- Were there any significant stumbling blocks while you were implementing your
  game (related to your design, or otherwise)?

  One significant problem that I had to think about was how to save the game & deal with the I/O. More specifically 
  I had to think about where the save files go. This was solved by creating a separate folder in the src folder to hold the 
  txt files that the saving of the game generates. These txt files will hold a bunch of small strings that preserve the
  game state when the game is ended or paused. And when the game is reopened, this txt file is read again and the strings
  that make it up are matched to the corresponding Block or Entity using the HashMap and help recreate the game.

- Evaluate your design. Is there a good separation of functionality? How well is
  private state encapsulated? What would you refactor, if given the chance? 
  Yes, the number of classes makes it clear that separation of functionality is demonstrated throughout this project. Private
  state is encapsulated well as EntityBlueprints and blocks and texture elements are all kept private. These can instead be accessed
  by getter and setter methods. If I were to redo something, I would actually try to implement text rendering because currently
  the help screen is just a nonfunctional button that has an image on top of it.


========================
=: External Resources :=
========================

- Cite any external resources (libraries, images, tutorials, etc.) that you may
  have used while implementing your game.
  
  https://docs.oracle.com/javase/tutorial/2d/images/loadimage.html
  https://docs.oracle.com/javase/tutorial/uiswing/events/intro.html
  https://www.youtube.com/channel/UCQ-W1KE9EYfdxhL6S4twUNw
  https://docs.oracle.com/javase/7/docs/api/java/awt/image/BufferedImage.html
  
