package util;

public class Vector2f {
	
	public static final Vector2f ZERO = new Vector2f(0, 0);
	
	private float x, y;
	
	public Vector2f(float x, float y) {
		this.x = x;
		this.y = y;
	}
	
	public void setX(float x) {
		this.x = x;
	}
	
	public void setY(float y) {
		this.y = y;
	}
	
	public void addX(float dx) {
		x += dx;
	}
	
	public void addY(float dy) {
		y += dy;
	}
	
	public float getX() {
		return x;
	}
	
	public float getY() {
		return y;
	}
	
	public Vector2f neg() {
		return new Vector2f(-x, -y);
	}
	
	public Vector2f clock90() {
		return new Vector2f(y, -x);
	}
	
	public Vector2f clock270() {
		return new Vector2f(-y, x);
	}
	
	public Vector2f sub(Vector2f b) {
		return new Vector2f(x - b.x, y - b.y);
	}
	
	public Vector2f add(Vector2f b) {
		return new Vector2f(x + b.x, y + b.y);
	}
	
	public Vector2f scale(float factor) {
		return new Vector2f(x*factor, y*factor);
	}
	
	public float atan2() {
		return (float) (Math.atan2(x, y)/Math.PI*180);
	}
	
	public float length() {
		return (float) Math.sqrt(x*x+y*y);
	}
	
	public void normalize() {
		float length = length(); //scale factor to normalize a vector is 1/length
		if(length < 0.00000001f) return; //if length is close enough to zero... don't divide by it. don't divide by 0.
		x /= length;
		y /= length;
	}
	
}
