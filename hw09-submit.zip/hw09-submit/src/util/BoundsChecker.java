package util;

public class BoundsChecker {
	
	//don't let other classes make instances of this class
	private BoundsChecker() {}
	
	//util method generally used to make sure a pixel's coordinates are on screen
	public static boolean inBounds(int min, int max, int num) {
		return min <= num && num < max;
	}
	
	//util method to put num between an interval
	public static int clamp(int min, int max, int num) {
		return Math.min(max, Math.max(min, num));
	}
	
	//util method to put num between an interval
	public static float clamp(float min, float max, float num) {
		return Math.min(max, Math.max(min, num));
	}
	
}
