package game;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;

import engine.GameO;
import engine.Input;
import engine.Main;
import engine.Render;
import engine.Tick;
import engine.entity.Entity;
import engine.entity.Fire;
import engine.entity.Giant;
import engine.entity.Lamp;
import engine.entity.Lamppost;
import engine.entity.Player;
import engine.entity.Zombie;
import engine.entity.inventory.Inventory;
import engine.menu.MenuSetup;
import engine.world.World;
import util.Vector2f;

//this is seperate from the engine-- this class uses the engine's classes, but the engine doesn't use this class
//this is the driver class that uses the engine to run a game
public class Game extends GameO {
	
	public static void main(String[] args) {
		Main.start(new Game()); //START THE GAME
	}
	
	private World current;
	private HeartDrawer playerHealth;
	
	public Game() {
		super("For\'t Night");
	}
	
	//=============================================================================================================
	
	//gets run in consistent intervals
	public void loop(int state) {
		if(state == 0) mainMenuLoop();
		if(state == 1 || state == 2 || state == 4 || state == 5 || state == 6 || state == 7) gameLoop();
		if(state == 3) helpMenuLoop();
	}
	
	public void helpMenuLoop() {
		MenuSetup.backButton.setHovered(Input.getMouseLocation());
		MenuSetup.helpScreen.setHovered(Input.getMouseLocation());
		if(Input.isClicked()) {
			MenuSetup.backButton.click(Input.getMouseLocation());
			MenuSetup.helpScreen.click(Input.getMouseLocation());
		}
	}
	
	public void mainMenuLoop() {
		MenuSetup.mainMenu.setHovered(Input.getMouseLocation());
		if(Input.isClicked()) MenuSetup.mainMenu.click(Input.getMouseLocation());
	}
	
	public static ArrayList<MenuSetup> activeAlerts = new ArrayList<MenuSetup>();
	public static Queue<MenuSetup> alertsToRemove = new LinkedList<MenuSetup>();
	
	public void gameLoop() {
		current.moveAllEntities();
		
		if(World.viewpoint.isDead()) {
			Main.renderer.renderCollection().addAll(MenuSetup.backButton.getAllButtons());
			MenuSetup.backButton.setHovered(Input.getMouseLocation());
			if(Input.isClicked()) {
				MenuSetup.backButton.click(Input.getMouseLocation());
			}
			return;
		} 
			
		for(MenuSetup ms : activeAlerts) {
			ms.setHovered(Input.getMouseLocation());
		}
		if(Input.isClicked()) {
			for(MenuSetup ms : activeAlerts) {
				ms.click(Input.getMouseLocation());
			}
		}
		
		while(!alertsToRemove.isEmpty()) {
			MenuSetup ms = alertsToRemove.remove();
			activeAlerts.remove(ms);
			Main.renderer.renderCollection().removeAll(ms.getAllButtons());
		}
		
//		if(!World.getCurrentWorld().wildfire0shown) {
//			if(Render.firesDrawn >= 5) {
//				World.getCurrentWorld().wildfire0shown = true;
//				
//				activeAlerts.add(MenuSetup.wildfireAlert);
//				Main.renderer.renderCollection().addAll(MenuSetup.wildfireAlert.getAllButtons());
//			}
//		}
//		if(!World.getCurrentWorld().wildfire1shown) {
//			if((System.currentTimeMillis()-World.getCurrentWorld().startTime)/1000 > 16 && !activeAlerts.containsAll(MenuSetup.wildfireAlert.getAllButtons())) {
//				World.getCurrentWorld().wildfire1shown = true;
//				
//				activeAlerts.add(MenuSetup.wildfireAlert2);
//				Main.renderer.renderCollection().addAll(MenuSetup.wildfireAlert2.getAllButtons());
//			}
//		}
//		if(!World.getCurrentWorld().wildfire2shown) {
//			if((System.currentTimeMillis()-World.getCurrentWorld().startTime)/1000 > 32 && !activeAlerts.containsAll(MenuSetup.wildfireAlert.getAllButtons())) {
//				World.getCurrentWorld().wildfire2shown = true;
//				
//				activeAlerts.add(MenuSetup.wildfireAlert3);
//				Main.renderer.renderCollection().addAll(MenuSetup.wildfireAlert3.getAllButtons());
//			}
//		}
//		if(!World.getCurrentWorld().wildfire3shown) {
//			if((System.currentTimeMillis()-World.getCurrentWorld().startTime)/1000 > 49 && !activeAlerts.containsAll(MenuSetup.wildfireAlert.getAllButtons())) {
//				World.getCurrentWorld().wildfire3shown = true;
//				
//				activeAlerts.add(MenuSetup.wildfireAlert4);
//				Main.renderer.renderCollection().addAll(MenuSetup.wildfireAlert4.getAllButtons());
//			}
//		}
//		if(!World.getCurrentWorld().wildfire4shown) {
//			if((System.currentTimeMillis()-World.getCurrentWorld().startTime)/1000 > 65 && !activeAlerts.containsAll(MenuSetup.wildfireAlert.getAllButtons())) {
//				World.getCurrentWorld().wildfire4shown = true;
//				
//				activeAlerts.add(MenuSetup.wildfireAlert5);
//				Main.renderer.renderCollection().addAll(MenuSetup.wildfireAlert5.getAllButtons());
//			}
//		}
		
		if(Math.random() < 0.005d) {
			for(Entity e : World.getCurrentWorld().allEntities()) {
				if(e.getBlueprint().equals(Lamp.LAMP)) if(Math.random() < 0.2d) World.getCurrentWorld().addEntity(
						new Entity(Fire.FIRE, e.getTrueX()+(float) (Math.random()*40-20), e.getTrueY()+(float) (Math.random()*40-20)));
				if(e.getBlueprint().equals(Lamppost.LAMPPOST)) if(Math.random() < 0.06d) World.getCurrentWorld().addEntity(
						new Entity(Fire.FIRE, e.getTrueX()+(float) (Math.random()*40-20), e.getTrueY()+(float) (Math.random()*40-20)));
			}
		}
		
		if(Tick.totalTicks % 960 == 0 && World.viewpoint.getHealth() < Player.PLAYER.getStartingHealth()) World.viewpoint.getHit(-1, Vector2f.ZERO);
		playerHealth.update(World.viewpoint.getHealth());
	}
	
	//=============================================================================================================
	
	//called when it exits state... do proper cleanup
	public void exitState(int state) {
		if(state == 0) exitMainMenu();
		if(state == 1 || state == 2 || state == 4 || state == 5 || state == 6 || state == 7) exitWorld();
		if(state == 3) exitHelpMenu();
	}
	
	public void exitHelpMenu() {
		Main.renderer.renderCollection().removeAll(MenuSetup.helpScreen.getAllButtons());
		Main.renderer.renderCollection().removeAll(MenuSetup.backButton.getAllButtons());
	}
	
	public void exitMainMenu() {
		Main.renderer.renderCollection().removeAll(MenuSetup.mainMenu.getAllButtons());
	}
	
	public void exitWorld() {
		current.saveWorld();
		World.setWorld(null);
		Inventory.INVENTORY.removeIconsFromRenderList();
		Main.renderer.renderCollection().removeAll(MenuSetup.backButton.getAllButtons());
		Inventory.INVENTORY.clearInventory();
		
		for(MenuSetup ms : activeAlerts) {
			Main.renderer.renderCollection().remove(ms.getAllButtons());
		}
		activeAlerts.clear();
	}
	
	//=============================================================================================================

	//called when it enters state... do proper initialization
	public void enterState(int state) {
		if(state == 0) enterMainMenu();
		if(state == 1) enterWorldi(1);
		if(state == 2) enterWorldi(2);
		if(state == 3) enterHelpMenu();
		if(state >= 4) enterWorldi(state - 1);
	}
	
	public void enterHelpMenu() {
		Main.renderer.renderCollection().addAll(MenuSetup.helpScreen.getAllButtons());
		Main.renderer.renderCollection().addAll(MenuSetup.backButton.getAllButtons());
	}
	
	public void enterMainMenu() {
		Main.renderer.renderCollection().addAll(MenuSetup.mainMenu.getAllButtons());
	}
	
	public void enterWorldi(int i) {
		current = new World(new DefaultWorldLoader(new Random(), 100, 100, "save" + i + ".txt"));
		World.setWorld(current);
		
		playerHealth = new HeartDrawer(Main.renderer.renderCollection(), Player.PLAYER.getStartingHealth(), World.viewpoint.getHealth());
	}
	
}
