package game;

import java.util.Collection;

import engine.graphics.GCanvas;
import engine.graphics.Texture;
import engine.graphics.Textured;

public class HeartDrawer {
	
	private int maxHearts;
	private int currentHearts;
	private Heart[] aliveHearts;
	private Heart[] deadHearts;
	private Collection<Textured> renderList;
	
	public HeartDrawer(Collection<Textured> renderList, int maxHearts, int currentHearts) {
		this.maxHearts = maxHearts;
		aliveHearts = new Heart[maxHearts];
		deadHearts = new Heart[maxHearts];
		this.currentHearts = currentHearts;
		
		for(int i = 0; i < maxHearts; i++) {
			float numberOfHeartsFromMiddle = (maxHearts-1)/2f - i;
			int xLocation = (int) (numberOfHeartsFromMiddle*20-10) + GCanvas.WIDTH/2;
			aliveHearts[i] = new Heart(xLocation, GCanvas.HEIGHT-112, Texture.HEART);
			deadHearts[i] = new Heart(xLocation, GCanvas.HEIGHT-112, Texture.HEART_DEAD);
		}
		
		this.renderList = renderList;
		drawHearts();
	}
	
	private void drawHearts() {
		for(int i = 0; i < maxHearts; i++) {
			if((maxHearts-i-1) < currentHearts) {
				renderList.remove(deadHearts[i]);
				renderList.add(aliveHearts[i]);
			} else {
				renderList.remove(aliveHearts[i]);
				renderList.add(deadHearts[i]);
			}
		}
		
	}
	
	private void loseHearts(int num) {
		for(int i = 0; i < num; i++) {
			currentHearts--;
			renderList.remove(aliveHearts[maxHearts-currentHearts-1]);
			renderList.add(deadHearts[maxHearts-currentHearts-1]);
		}
	}
	
	private void gainHearts(int num) {
		for(int i = 0; i < num; i++) {
			renderList.remove(deadHearts[maxHearts-currentHearts-1]);
			renderList.add(aliveHearts[maxHearts-currentHearts-1]);
			currentHearts++;
		}
	}
	
	public void update(int newHealth) {
		int change = newHealth - currentHearts;
		if(change < 0) loseHearts(-change);
		if(change > 0) gainHearts(change);
	}
	
	private static class Heart implements Textured {
		
		private int x, y;
		private Texture tex;
		
		public Heart(int x, int y, Texture tex) {
			this.x = x;
			this.y = y;
			this.tex = tex;
		}
		
		public int getX() {
			return x;
		}

		public int getY() {
			return y;
		}

		public Texture getTexture() {
			return tex;
		}
		
		public int getZ() {
			return 20;
		}
		
	}
}
