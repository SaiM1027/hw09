package game;

import java.util.HashMap;

import engine.block.Asphalt;
import engine.block.BlockBlueprint;
import engine.block.Bricks;
import engine.block.Dirt;
import engine.block.Grass;
import engine.block.Pavement;
import engine.block.RoadHor;
import engine.block.RoadVer;
import engine.block.Stone;
import engine.entity.DeadStump;
import engine.entity.EntityBlueprint;
import engine.entity.Fire;
import engine.entity.Giant;
import engine.entity.Lamp;
import engine.entity.Lamppost;
import engine.entity.Player;
import engine.entity.Spray;
import engine.entity.Tree;
import engine.entity.TreeBurnFull;
import engine.entity.TreeBurnHalf;
import engine.entity.TreeSapling;
import engine.entity.TreeStump;
import engine.entity.Zombie;

public class WorldGenHelper {
	
	//the normal world generation helper
	public static final WorldGenHelper DEFAULT = new WorldGenHelper();
	
	private HashMap<String, BlockBlueprint> StringToBlock = new HashMap<String, BlockBlueprint>();
	private HashMap<BlockBlueprint, String> blockToString = new HashMap<BlockBlueprint, String>();
	
	private HashMap<String, EntityBlueprint> stringToEntity = new HashMap<String, EntityBlueprint>();
	private HashMap<EntityBlueprint, String> entityToString = new HashMap<EntityBlueprint, String>();
	
	//don't make an instance of this class in other class... private
	private WorldGenHelper() {
		addStringAndBlock("b", Bricks.BRICKS);
		addStringAndBlock("s", Stone.STONE);
		addStringAndBlock("g", Grass.GRASS);
		addStringAndBlock("d", Dirt.DIRT);
		addStringAndBlock("h", RoadHor.ROADHOR);
		addStringAndBlock("v", RoadVer.ROADVER);
		addStringAndBlock("p", Pavement.PAVEMENT);
		addStringAndBlock("a", Asphalt.ASPHALT);
		
		addStringAndEntity("P", Player.PLAYER);
		addStringAndEntity("T", Tree.TREE);
		addStringAndEntity("S", TreeStump.TREE_STUMP);
		addStringAndEntity("H", TreeSapling.TREE_SAPLING);
		addStringAndEntity("L", Lamp.LAMP);
		addStringAndEntity("G", Lamppost.LAMPPOST);
		addStringAndEntity("Z", Zombie.ZOMBIE);
		addStringAndEntity("B", Giant.GIANT);
		addStringAndEntity("D", DeadStump.TREE_STUMP);
		addStringAndEntity("F", Fire.FIRE);
		addStringAndEntity("Tree_burned_half", TreeBurnHalf.TREE_BURN_HALF);
		addStringAndEntity("Tree_burned_full", TreeBurnFull.TREE_BURN_FULL);
		addStringAndEntity("SPRAY", Spray.SPRAY);
	}
	
	public BlockBlueprint getBlockFromString(String identifier) {
		return StringToBlock.get(identifier);
	}
	
	public String getStringFromBlock(BlockBlueprint b) {
		return blockToString.get(b);
	}
	
	//associate a specific string with a block-- this is for reading and writing save files
	public void addStringAndBlock(String identifier, BlockBlueprint b) {
		StringToBlock.put(identifier, b);
		blockToString.put(b, identifier);
	}
	
	
	//============================================
	
	public EntityBlueprint getEntityFromString(String id) {
		return stringToEntity.get(id);
	}
	
	public String getStringFromEntity(EntityBlueprint b) {
		return entityToString.get(b);
	}
	
	//associate an entity with a string id-- this is for reading and writing save files
	public void addStringAndEntity(String id, EntityBlueprint e) {
		stringToEntity.put(id, e);
		entityToString.put(e, id);
	}
}
