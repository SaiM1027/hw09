package game;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.StringTokenizer;

import engine.block.BlockBlueprint;
import engine.block.Bricks;
import engine.entity.DeadStump;
import engine.entity.Entity;
import engine.entity.Lamp;
import engine.entity.Lamppost;
import engine.entity.Player;
import engine.entity.Tree;
import engine.entity.inventory.Inventory;
import engine.world.World;
import engine.world.WorldGenerator;

public class DefaultWorldLoader implements WorldGenerator {
	
	private String[][] mapAtStart;
	private List<Entity> allEnts; 
	private Entity player;
	private String pathToSave;
	private String pathToDir;
	
	//create a world procedurally
	public DefaultWorldLoader(Random r, int width, int height, String saveName) {
		pathToDir = System.getProperty("user.home") + "/PA/maps";
		pathToSave = pathToDir + "/" + saveName;
		File saveFile = new File(pathToSave);
		
		if(saveFile.exists()) {
			loadFromSaveFile(saveFile);
		} else {
			new File(pathToDir).mkdirs();
			createProcedurally(r, width, height);
		}
	}
	
	private void createProcedurally(Random r, int width, int height) {
		mapAtStart = new String[width][height];
		allEnts = new ArrayList<Entity>();
		
		//by default, form the world full of grass
		for(int i = 0; i < width; i++) {
			for(int j = 0; j < height; j++) {
				mapAtStart[i][j] = "g";
			}
		}
		
		//create forest areas
		for(int i = 0; i < (width*height)/1000; i++) {
			float x = r.nextFloat()*width*32;	//forest center
			float y = r.nextFloat()*height*32; 
			float radius = width*height/15;
			
			boolean deadForest = r.nextInt(100) < 20;
			
			for(int t = 0; t < (width*height)/40; t++) { //spawn trees
				float angle = r.nextFloat()*360; //angle from center
				float distance = r.nextFloat()*radius; //distance from center
				
				allEnts.add(new Entity(deadForest ? DeadStump.TREE_STUMP : Tree.TREE, (float)(Math.cos(angle))*distance+x, (float)(Math.sin(angle))*distance+y));
			}
		}
		
		//spawn lamps
		for(int i = 0; i < (width*height)/1000; i++) {
			float x = r.nextFloat()*width*32;
			float y = r.nextFloat()*height*32;
			
			allEnts.add(new Entity(Lamp.LAMP, x, y));
		}
		
		//spawn areas of bricks/stone/pavement
		for(int i = 0; i < (width*height)/1000; i++) {
			float x = r.nextFloat()*width*32;	//pavement center
			float y = r.nextFloat()*height*32; 
			float radius = width*height/40;
			String tile= "b";
			
			int tileType = r.nextInt(3);
			if(tileType == 0) tile = "s";
			if(tileType == 1) tile = "p";
			
			for(int t = 0; t < (width*height)/10; t++) { //place tiles
				float angle = r.nextFloat()*360; //angle from center
				float distance = r.nextFloat()*radius; //distance from center
				float fX = (float)(Math.cos(angle))*distance+x;
				float fY = (float)(Math.sin(angle))*distance+y;
				int tileX = (int)(fX)/32;
				int tileY = (int)(fY)/32;
				if(tileX >= width || tileX < 0 || tileY >= height || tileY < 0) continue;				
				mapAtStart[tileX][tileY] = tile;
			}
			
			int numLamps = r.nextInt(3);
			for(int t = 0; t < numLamps; t++) { //place tiles
				float angle = r.nextFloat()*360; //angle from center
				float distance = r.nextFloat()*radius; //distance from center
				float fX = (float)(Math.cos(angle))*distance+x;
				float fY = (float)(Math.sin(angle))*distance+y;
				allEnts.add(new Entity(Lamp.LAMP, fX, fY));
			}
		}
		
		//spawn roads
		for(int i = 0; i < height/15; i++) {
			int y = r.nextInt(height);	
			for(int x = 0; x < width; x++) {
				if(y-1 >= 0) mapAtStart[x][y-1] = "a";
				mapAtStart[x][y] = "h";
				if(y+1 < height) mapAtStart[x][y+1] = "a";
				int offset = r.nextInt(10);
				if(x % 10 == offset) {
					allEnts.add(new Entity(Lamppost.LAMPPOST, x*32, (y+2)*32+16));
					allEnts.add(new Entity(Lamppost.LAMPPOST, x*32, (y-2)*32+16));
				}
			}
		}
		
		for(int i = 0; i < 5; i++) notificationStatuses.add(false);
									//places player in center of map
		player = new Entity(Player.PLAYER, width*16, height*16);
		allEnts.add(player);
	}
	
	private void loadFromSaveFile(File saveFile) {
		try {
			BufferedReader br = new BufferedReader(new FileReader(saveFile));
			
			//the first line contains two ints-- the dimensions
			StringTokenizer dimensions = new StringTokenizer(br.readLine());
			int width = Integer.parseInt(dimensions.nextToken());
			int height = Integer.parseInt(dimensions.nextToken());
			mapAtStart = new String[width][height];
			
			//read the following table of blocks
			for(int i = 0; i < height; i++) {
				StringTokenizer row = new StringTokenizer(br.readLine());
				for(int j = 0; j < width; j++) {
					mapAtStart[j][i] = row.nextToken(); 
				}
			}
			
			//read ents
			int numEnts = Integer.parseInt(br.readLine()); //number of ents
			
			allEnts = new ArrayList<Entity>(numEnts);
			for(int i = 0; i < numEnts; i++) {
				StringTokenizer row = new StringTokenizer(br.readLine()); //entities are described by an ID, coordinates, and health
				String id = row.nextToken();
				float x = Float.parseFloat(row.nextToken());
				float y = Float.parseFloat(row.nextToken());
				int health = Integer.parseInt(row.nextToken());
				
				Entity e = new Entity(WorldGenHelper.DEFAULT.getEntityFromString(id), x, y, health);
				allEnts.add(e);	
				if(WorldGenHelper.DEFAULT.getStringFromEntity(Player.PLAYER).equals(id)) player = e;
			}
			//read notification status
			for(int i = 0; i < 5; i++) {
				notificationStatuses.add(Boolean.parseBoolean(br.readLine()));
			}
			
			score = Integer.parseInt(br.readLine());
			
			//finish
			br.close();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public int score = 0;
	
	public int getScore() {
		return score;
	}
	
	public ArrayList<Boolean> notificationStatuses = new ArrayList<Boolean>();
	
	public List<Boolean> getNotificationStatuses() {
		return notificationStatuses;
	}
	
	public List<Entity> getStartingEnts() {
		return allEnts;
	}

	public Entity getPlayer() {
		return player;
	}
	
	public BlockBlueprint getBlock(int i, int j) {
		if(WorldGenHelper.DEFAULT.getBlockFromString(mapAtStart[i][j]) != null) return WorldGenHelper.DEFAULT.getBlockFromString(mapAtStart[i][j]);
		return Bricks.BRICKS; //default fall-back block if for some reason a block in the save file doesn't exist
	}
	
	//save world to text file
	public void saveWorld(World one) {
		try {
			PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(pathToSave))); //prints to the save file
			pw.println(getWidth() + " " + getHeight()); //print dimensions of world
			
			for(int i = 0; i < getHeight(); i++) {
				for(int j = 0; j < getWidth(); j++) {
					pw.print(WorldGenHelper.DEFAULT.getStringFromBlock(one.getBlock(j, i).getBlueprint()) + " "); //print blocks
				}
				pw.println();
			}
			
			//print ents
			pw.println(one.allEntities().size());
			for(Entity e : one.allEntities()) {
				pw.println(WorldGenHelper.DEFAULT.getStringFromEntity(e.getBlueprint()) + " " + 
			e.getTrueX() + " " + e.getTrueY() + " " + e.getHealth());
			}
			
			//print notifications status
			pw.println(one.wildfire0shown);
			pw.println(one.wildfire1shown);
			pw.println(one.wildfire2shown);
			pw.println(one.wildfire3shown);
			pw.println(one.wildfire4shown);
			
			pw.println(one.score);
			
			//finish
			pw.close();
			
			//delete the file if the player is actually dead
			if(World.viewpoint.isDead()) {
				new File(pathToSave).delete();
			}
			
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public int getWidth() {
		return mapAtStart.length;
	}
	
	public int getHeight() {
		return mapAtStart[0].length;
	}
	
}
