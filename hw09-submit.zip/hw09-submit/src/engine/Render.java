package engine;

import java.awt.Rectangle;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import engine.block.Block;
import engine.entity.Entity;
import engine.entity.Fire;
import engine.graphics.Frame;
import engine.graphics.GCanvas;
import engine.graphics.Textured;
import engine.world.World;

public class Render {

	//this is the frame object that manages the JFrame
	private Frame frame;
	
	public Render(String frameTitle) {
		frame = new Frame(frameTitle);
	}
	
	private List<Textured> toRender = new ArrayList<Textured>();
	
	public List<Textured> renderCollection() {
		return toRender;
	}
	
	public static int firesDrawn = 0;
	private static Rectangle screen = new Rectangle(0, 0, GCanvas.WIDTH, GCanvas.HEIGHT);
	
	public void run() {
		firesDrawn = 0;
		//clear the screen, sometimes unnecessary so may be commented out
		frame.getCanvas().clearScreen();
		
		if(World.getCurrentWorld() != null) {
			//viewable pixels
			int leftMostPixel = World.viewpoint.getPixelX()-GCanvas.WIDTH/2;
			int rightMostPixel = World.viewpoint.getPixelX()+GCanvas.WIDTH/2;
			int upMostPixel = World.viewpoint.getPixelY()-GCanvas.HEIGHT/2;
			int bottomMostPixel = World.viewpoint.getPixelY()+GCanvas.HEIGHT/2;
			
			//their associated blocks
			int leftMostBlock = leftMostPixel / 32;
			int rightMostBlock = rightMostPixel / 32;
			int upMostBlock = upMostPixel / 32;
			int bottomMostBlock = bottomMostPixel / 32;
			
			//renders all blocks in between
			for(int i = Math.max(leftMostBlock, 0); i <= Math.min(rightMostBlock, World.getCurrentWorld().getWidth()-1); i++) {
				for(int j = Math.max(upMostBlock, 0); j <= Math.min(bottomMostBlock, World.getCurrentWorld().getHeight()-1); j++) {
					Block b = World.getCurrentWorld().getBlock(i, j);
					
					frame.drawTextureWithBrightnessAndCelShading(b.getTexture(), b.getX(), b.getY(), 
							World.getCurrentWorld().getRed(i, j), 
							World.getCurrentWorld().getGreen(i, j), 
							World.getCurrentWorld().getBlue(i, j), 
							5*World.viewpoint.getHealth()+2);
				}
			}
			
			//renders entities as well
			for(Entity e : World.getCurrentWorld().allEntities()) {
				Rectangle entityTex = new Rectangle(e.getX(), e.getY(), e.getTexture().WIDTH, e.getTexture().HEIGHT);
				if(entityTex.intersects(screen)) {//only draw entity if you can see at least part of it on screen
					if(!e.renderedWithFullBrightness())
						frame.drawTextureWithBrightnessAndCelShading(e.getTexture(), e.getX(), e.getY(),
								World.getCurrentWorld().getRed(e.getBlockX(), e.getBlockY()), 
								World.getCurrentWorld().getGreen(e.getBlockX(), e.getBlockY()), 
								World.getCurrentWorld().getBlue(e.getBlockX(), e.getBlockY()), 
								5*World.viewpoint.getHealth()+2);
					else 
						frame.drawTexture(e.getTexture(), e.getX(), e.getY());
					
					if(e.getBlueprint().equals(Fire.FIRE)) firesDrawn++;
				}
			}
		}
		
		//renders other textured objects in the render set
		Collections.sort(toRender, sortByZ);
		for(Textured t : toRender) {
			frame.drawTexture(t.getTexture(), t.getX(), t.getY());
		}
		
		//update the screen
		frame.paint();
	}
	
	private Comparator<Textured> sortByZ = new Comparator<Textured>() {
		public int compare(Textured a, Textured b) {
			return a.getZ() - b.getZ();
		}
	};
	
	public Frame getFrame() {
		return frame;
	}
}
