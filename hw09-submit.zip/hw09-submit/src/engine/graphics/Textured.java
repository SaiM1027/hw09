package engine.graphics;

//something with a texture and screen coordinates, which is enough information to get rendered to the screen
public interface Textured {
	
	public int getX();
	public int getY();
	public Texture getTexture();
	public int getZ();
	
}
