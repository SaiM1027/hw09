package engine.graphics;

import java.awt.image.BufferedImage;
import java.io.InputStream;

import javax.imageio.ImageIO;

public class TextureAtlas {
	
	public static final TextureAtlas PLAYERLEFT = new TextureAtlas(40, 32, 10, "ents/playerLeft.png");
	public static final TextureAtlas PLAYERRIGHT = new TextureAtlas(40, 32, 10, "ents/playerRight.png");
	public static final TextureAtlas PLAYERUP = new TextureAtlas(40, 32, 10, "ents/playerUp.png");
	public static final TextureAtlas PLAYERDOWN = new TextureAtlas(40, 32, 10, "ents/playerDown.png");
	
	public static final TextureAtlas ZOMBIELEFT = new TextureAtlas(40, 32, 10, "ents/zombieLeft.png");
	public static final TextureAtlas ZOMBIERIGHT = new TextureAtlas(40, 32, 10, "ents/zombieRight.png");
	public static final TextureAtlas ZOMBIEUP = new TextureAtlas(40, 32, 10, "ents/zombieUp.png");
	public static final TextureAtlas ZOMBIEDOWN = new TextureAtlas(40, 32, 10, "ents/zombieDown.png");
	
	public static final TextureAtlas GIANTLEFT = new TextureAtlas(320, 256, 80, "ents/giantLeft.png");
	public static final TextureAtlas GIANTRIGHT = new TextureAtlas(320, 256, 80, "ents/giantRight.png");
	public static final TextureAtlas GIANTUP = new TextureAtlas(320, 256, 80, "ents/giantUp.png");
	public static final TextureAtlas GIANTDOWN = new TextureAtlas(320, 256, 80, "ents/giantDown.png");
	
	public static final TextureAtlas NUMERALS = new TextureAtlas(100, 10, 10, "fonts/numerals.png");
	
	public static final TextureAtlas FIRE = new TextureAtlas(128, 32, 32, "ents/fire.png");
	
	public final int WIDTH, HEIGHT;
	private Texture[] textures;
	
	//Load an image file that contains several textures next to each other
	public TextureAtlas(int w, int h, int tileWidth, String fileName) { //w and h are the dimensions of the whole image. tileWidth is the length of the subimage. 
		WIDTH = w;
		HEIGHT = h;
		textures = new Texture[w/tileWidth];
		
		int[][] pixels = new int[w][h];
		
		try {
			InputStream fis = Class.class.getResourceAsStream("/" + fileName);
			BufferedImage image = ImageIO.read(fis);
			
			for(int i = 0; i < w; i++) {
				for(int j = 0; j < h; j++) {
					pixels[i][j] = image.getRGB(i, j);		//reads the whole image into a 2D array
				}
			}
			
			fis.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		//copy each subimage into a new texture
		for(int i = 0; i < textures.length; i++) { 
			int[][] part = new int[tileWidth][h];
			for(int j = tileWidth*i; j < tileWidth*(i+1); j++) {
				for(int k = 0; k < h; k++) {
					part[j-tileWidth*i][k] = pixels[j][k];
				}
			}
			
			textures[i] = new Texture(part);
		}
	}
	
	//how many textures are in this whole image
	public int numTextures() {
		return textures.length;
	}
	
	//get the i-th subimage in this whole image
	public Texture getTexture(int i) {
		return textures[i];
	}
	
}
