package engine.graphics;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferInt;

import engine.world.World;
import util.BoundsChecker;
import util.Vector2f;

public class GCanvas extends Canvas {
	
	private static final long serialVersionUID = 2511784101865055994L; //the compiler kept on giving me warnings until I did this

	public static final int WIDTH = 768, HEIGHT = 576;
	
	private BufferedImage img;		//represents what gets drawn to screen
	private int[] pixels;			//changing pixels[] affects BufferedImage img
	private int[][] pixels2D;		//pixels2D[][] gets copied into pixels[] each render loop
	
	public GCanvas() {
		img = new BufferedImage(WIDTH, HEIGHT, BufferedImage.TYPE_INT_RGB);
		pixels = ((DataBufferInt) img.getRaster().getDataBuffer()).getData();
		pixels2D = new int[WIDTH][HEIGHT];
	}
	
	private static Vector2f centerOfScreen = new Vector2f(GCanvas.WIDTH/2, GCanvas.HEIGHT/2);
	
	public static Vector2f centerOfScreen() {
		return centerOfScreen;
	}
	
	public void draw() {
		BufferStrategy bs = this.getBufferStrategy();
		if(bs == null) {
			this.createBufferStrategy(3);
			return;
		}
		
		copyPixels();
		
		Graphics g = bs.getDrawGraphics();			//this Graphics object draws to the Canvas
		g.drawImage(img, 0, 0, WIDTH, HEIGHT, null);	//draw the image
		
		if(World.getCurrentWorld() != null) {
			g.setFont(new Font("Georgia", Font.BOLD, 18));
			g.setColor(Color.CYAN);
			g.drawString("SCORE: " + World.getCurrentWorld().score, 600, 500);
		}
		
		g.dispose();
		bs.show();
	}
	
	public void clearScreen() {
		drawTexture(Texture.BACKGROUND.getTexture(), 0, 0);
	}
	
	//copies pixels2d[][] into pixels[]
	public void copyPixels() {
		for(int i = 0; i < WIDTH; i++) {
			for(int j = 0; j < HEIGHT; j++) {
				pixels[j*WIDTH+i] = pixels2D[i][j];
			}
		}
	}
	
	//top left corner is (x, y)
	public void drawTexture(int[][] texture, int x, int y) {
		drawTextureWithBrightness(texture, x, y, 1, 1, 1);
	}
	
	//use applyBrightness() method
	public void drawTextureWithBrightness(int[][] texture, int x, int y, float r, float g, float b) {
		for(int i = 0; i < texture.length; i++) {
			for(int j = 0; j < texture[0].length; j++) {
				int drawX = i+x;
				int drawY = j+y;
				if(BoundsChecker.inBounds(0, WIDTH, drawX) && BoundsChecker.inBounds(0, HEIGHT, drawY) && texture[i][j] != -16777216) {
					pixels2D[drawX][drawY] = applyBrightness(texture[i][j], r, g, b);
				}
			}
		}
	}
	
	//specific art style
	public void drawTextureWithBrightnessAndCelShading(int[][] texture, int x, int y, float r, float g, float b, int floors) {
		for(int i = 0; i < texture.length; i++) {
			for(int j = 0; j < texture[0].length; j++) {
				int drawX = i+x;
				int drawY = j+y;
				if(BoundsChecker.inBounds(0, WIDTH, drawX) && BoundsChecker.inBounds(0, HEIGHT, drawY) && texture[i][j] != -16777216) {
					pixels2D[drawX][drawY] = applyCelShading(applyBrightness(texture[i][j], r, g, b), floors);
				}
			}
		}
	}
	
	//applies the cel shading art style
	private int applyCelShading(int color, int floors) {
		int red = (color & 0xff0000) >> 16;
		int green = (color & 0xff00) >> 8;
		int blue = (color & 0xff);
		
		int gap = 255/floors; //how many levels of intensity between each band
		
		red = ((red)/gap)*gap;
		blue = ((blue)/gap)*gap;
		green = ((green)/gap)*gap;
				
		return (red << 16) + (green << 8) + blue;
	}
	
	//r g b should be getR(), getG(), and getB() from the World class. Basically the intensity of the lighting in the color channels.
	private int applyBrightness(int color, float r, float g, float b) {
		//the bits are organized like aaaaaaaaarrrrrrrrggggggggbbbbbbbb where r, g, and b indicate which color channel the bit is for... for now, the a (alpha) channel is not used
		int red = (int) (((color & 0xff0000) >> 16)*r); 
		int green = (int) (((color & 0xff00) >> 8)*g);
		int blue = (int) (((color & 0xff))*b);
		red = BoundsChecker.clamp(0, 255, red);
		green = BoundsChecker.clamp(0, 255, green);
		blue = BoundsChecker.clamp(0, 255, blue);
		
		return (red << 16) + (green << 8) + blue;
	}
	
}
