package engine.graphics;

import java.awt.image.BufferedImage;
import java.io.InputStream;

import javax.imageio.ImageIO;

public class Texture {
	
	//load in various textures
	public static final Texture STONE = new Texture(32, 32, "stone.png"),
			ASPHALT = new Texture(32, 32, "road.png"), BRICKS = new Texture(32, 32, "bricks.png"),
			ROAD_VERT = new Texture(32, 32, "roadVert.png"), ROAD_HOR = new Texture(32, 32, "roadHor.png"),
			PAVEMENT = new Texture(32, 32, "pavement.png"), DIRT = new Texture(32, 32, "dirt.png"),
			GRASS = new Texture(32, 32, "grass.png");
	
	public static final Texture TREE = new Texture(64, 64, "ents/tree.png"),
			TREE_SAPLING = new Texture(32, 32, "ents/treeSapling.png"),
			TREE_STUMP = new Texture(64, 64, "ents/treeStump.png"),
			TREE_BURNED_HALF = new Texture(64, 64, "ents/treeBurnHalf.png"),
			TREE_BURNED_FULL = new Texture(64, 64, "ents/treeBurnFull.png");
	
	public static final Texture LAMP = new Texture(32, 32, "ents/lamp.png"),
			LAMPPOST = new Texture(32, 64, "ents/lamppost.png");
	
	public static final Texture SAVE1 = new Texture(80, 80, "buttons/save1.png"),
			SAVE1_HOVERED = new Texture(80, 80, "buttons/save1hovered.png"),
			SAVE2 = new Texture(80, 80, "buttons/save2.png"),
			SAVE2_HOVERED = new Texture(80, 80, "buttons/save2hovered.png"),
			SAVE3 = new Texture(80, 80, "buttons/save3.png"),
			SAVE3_HOVERED = new Texture(80, 80, "buttons/save3hovered.png"),
			SAVE4 = new Texture(80, 80, "buttons/save4.png"),
			SAVE4_HOVERED = new Texture(80, 80, "buttons/save4hovered.png"),
			SAVE5 = new Texture(80, 80, "buttons/save5.png"),
			SAVE5_HOVERED = new Texture(80, 80, "buttons/save5hovered.png"),
			SAVE6 = new Texture(80, 80, "buttons/save6.png"),
			SAVE6_HOVERED = new Texture(80, 80, "buttons/save6hovered.png"),
			HELP = new Texture(200, 82, "buttons/help.png"),
			HELP_HOVERED = new Texture(200, 82, "buttons/helpHovered.png"),
			BACK = new Texture(200, 82, "buttons/back.png"),
			BACK_HOVERED = new Texture(200, 82, "buttons/backHovered.png"),
			HELPMENU = new Texture(600, 330, "buttons/helpmenu.png");
	
	public static final Texture BACKGROUND = new Texture(768, 576, "background.png");
	
	public static final Texture WOOD = new Texture(32, 32, "icons/wood.png"), 
			METAL = new Texture(32, 32, "icons/metal.png"),
			WEAPON1 = new Texture(32, 32, "icons/weapon1.png"),
			WEAPON2 = new Texture(32, 32, "icons/weapon2.png"),
			WEAPON3 = new Texture(32, 32, "icons/weapon3.png");
	
	public static final Texture WEAPON_1_RECIPE = new Texture(80, 80, "buttons/weapon1recipe.png"),
			WEAPON_1_RECIPE_HOVERED = new Texture(80, 80, "buttons/weapon1recipeHovered.png"),
			WEAPON_2_RECIPE = new Texture(80, 80, "buttons/weapon2recipe.png"),
			WEAPON_2_RECIPE_HOVERED = new Texture(80, 80, "buttons/weapon2recipeHovered.png"),
			WEAPON_3_RECIPE = new Texture(80, 80, "buttons/weapon3recipe.png"),
			WEAPON_3_RECIPE_HOVERED = new Texture(80, 80, "buttons/weapon3recipeHovered.png"),
			LAMP_RECIPE = new Texture(80, 80, "buttons/lampRecipe.png"),
			LAMP_RECIPE_HOVERED = new Texture(80, 80, "buttons/lampRecipeHovered.png");
	
	public static final Texture HEART = new Texture(8, 8, "icons/heart.png"),
			HEART_DEAD = new Texture(8, 8, "icons/heartdead.png");
	
	public static final Texture WILDFIRE0 = new Texture(200, 566, "buttons/wildfire0.png"),
			WILDFIRE0_HOVERED = new Texture(200, 566, "buttons/wildfire0hovered.png");
	public static final Texture WILDFIRE1 = new Texture(200, 566, "buttons/wildfire1.png"),
			WILDFIRE1_HOVERED = new Texture(200, 566, "buttons/wildfire1hovered.png");
	public static final Texture WILDFIRE2 = new Texture(200, 566, "buttons/wildfire2.png"),
			WILDFIRE2_HOVERED = new Texture(200, 566, "buttons/wildfire2hovered.png");
	public static final Texture WILDFIRE3 = new Texture(200, 566, "buttons/wildfire3.png"),
			WILDFIRE3_HOVERED = new Texture(200, 566, "buttons/wildfire3hovered.png");
	public static final Texture WILDFIRE4 = new Texture(200, 566, "buttons/wildfire4.png"),
			WILDFIRE4_HOVERED = new Texture(200, 566, "buttons/wildfire4hovered.png");
	
	public static final Texture SPRAY = new Texture(3, 3, "ents/spray.png");
	
	public final int WIDTH, HEIGHT;
	private int[][] texture;
	
	//loads in a 2D image
	public Texture(int w, int h, String fileName) {
		WIDTH = w;
		HEIGHT = h;
		texture = new int[w][h];
		
		try {
			InputStream fis = Class.class.getResourceAsStream("/" + fileName);
			BufferedImage image = ImageIO.read(fis);
			
			for(int i = 0; i < w; i++) {
				for(int j = 0; j < h; j++) {
					texture[i][j] = image.getRGB(i, j);		//reads the image into the 2D array
				}
			}
			
			fis.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public Texture(int[][] tex) {		//copies the given int[][] into a Texture object
		texture = tex;
		WIDTH = tex.length;
		HEIGHT = tex[0].length;
	}
	
	public int[][] getTexture() { //returns the 2D array that represents the texture
		return texture;
	}

}
