package engine.graphics;

import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.JFrame;

import engine.Input;

public class Frame {

	private JFrame frame;
	private GCanvas canvas;
	
	public static boolean closeRequested = false;

	public Frame(String title) {
		// initialize Jframe
		frame = new JFrame(title);
		frame.setSize(GCanvas.WIDTH, GCanvas.HEIGHT);
		frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		frame.setResizable(false);
		canvas = new GCanvas();

		// add input listeners
		Input in = new Input();
		canvas.addMouseListener(in);
		canvas.addMouseMotionListener(in);
		canvas.addKeyListener(in);

		frame.add(canvas);
		frame.addWindowListener(new WindowListener() {

			public void windowOpened(WindowEvent e) {}
			public void windowClosing(WindowEvent e) {
				closeRequested = true;
				System.exit(0);
			}
			public void windowClosed(WindowEvent e) {}
			public void windowIconified(WindowEvent e) {}
			public void windowDeiconified(WindowEvent e) {}
			public void windowActivated(WindowEvent e) {}
			public void windowDeactivated(WindowEvent e) {}
		});

		frame.setVisible(true);
	}

	// access the canvas through the frame object, draws textures such that top
	// left corner is (x, y)
	public void drawTexture(Texture texture, int x, int y) {
		canvas.drawTexture(texture.getTexture(), x, y);
	}

	// access the canvas through the frame object, draws textures such that top
	// left corner is (x, y)
	public void drawTextureWithBrightness(Texture texture, int x, int y, float r, float g, float b) {
		canvas.drawTextureWithBrightness(texture.getTexture(), x, y, r, g, b);
	}
	
	// access the canvas through the frame object, draws textures such that top
	// left corner is (x, y)
	public void drawTextureWithBrightnessAndCelShading(Texture texture, int x, int y, float r, float g, float b, int floors) {
		canvas.drawTextureWithBrightnessAndCelShading(texture.getTexture(), x, y, r, g, b, floors);
	}

	// access the canvas through this class
	public GCanvas getCanvas() {
		return canvas;
	}

	// access the canvas through this class
	public void paint() {
		canvas.draw();
	}
}
