package engine;

//the programmer extends this class to make their driver
public abstract class GameO {
	
	protected String title;
	
	public GameO(String t) {
		title = t;
	}
	
	public abstract void loop(int state); //gets run in consistent intervals
	public abstract void exitState(int state);	//gets run when exiting state
	public abstract void enterState(int state); //gets run when entering state
	
}
