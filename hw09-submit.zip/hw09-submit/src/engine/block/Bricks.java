package engine.block;

import engine.graphics.Texture;

public class Bricks extends BlockBlueprint {
	
	public static final Bricks BRICKS = new Bricks(); //relatively boring block... just a brick texture
	
	private Bricks() {		
		super(Texture.BRICKS);
	}

}
