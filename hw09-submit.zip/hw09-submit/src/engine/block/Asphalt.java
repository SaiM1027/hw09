package engine.block;

import engine.graphics.Texture;

public class Asphalt extends BlockBlueprint {

	public static final Asphalt ASPHALT = new Asphalt();//THE Asphalt block
	
	private Asphalt() {
		super(Texture.ASPHALT); //use that texture
	}
	

}
