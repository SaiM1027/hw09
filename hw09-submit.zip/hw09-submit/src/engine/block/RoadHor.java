package engine.block;

import engine.graphics.Texture;

public class RoadHor extends BlockBlueprint {
	
	public static final RoadHor ROADHOR = new RoadHor();
	//use this to create horizontal roads
	
	private RoadHor() {
		super(Texture.ROAD_HOR);
	}
	
}
