package engine.block;

import engine.graphics.Texture;

//instances of this class will hold attributes that can be given to blocks, such as texture
public abstract class BlockBlueprint {
	
	private Texture tex;
	
	public BlockBlueprint(Texture tex) {
		this.tex = tex;
	}
	
	public Texture getTexture() {
		return tex;
	}
	
}
