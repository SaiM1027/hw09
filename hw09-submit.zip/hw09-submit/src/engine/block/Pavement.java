package engine.block;

import engine.graphics.Texture;

public class Pavement extends BlockBlueprint {
	
	public static final Pavement PAVEMENT = new Pavement();//use this in the Block constructor to create pavement blocks
	
	private Pavement() {
		super(Texture.PAVEMENT);
	}
	
}
