package engine.block;

import engine.graphics.Texture;

public class RoadVer extends BlockBlueprint {
	
	public static final RoadVer ROADVER = new RoadVer();
	//vertical roads
	
	private RoadVer() {
		super(Texture.ROAD_VERT);
	}
	
}
