package engine.block;

import engine.graphics.GCanvas;
import engine.graphics.Texture;
import engine.graphics.Textured;
import engine.world.World;

//represents the blocks that tile the screen
public class Block implements Textured {
	
	private BlockBlueprint bp;		//this block gets its attributes from its blueprint
	protected int worldX, worldY;
	
	public Block(int worldX, int worldY, BlockBlueprint bp) {
		this.worldX = worldX;
		this.worldY = worldY;
		this.bp = bp;
	}
	
	//(x, y) in the world, x and y are positive integers (0, 0), (1, 0), (0, 1), (1, 1)...
	public int getWorldX() {
		return worldX;
	}
	
	public int getWorldY() {
		return worldY;
	}
	
	//(pixelX, pixelY) precise coordinates pixelX and pixelY are 32*positive integers (0, 0), (32, 0), (0, 32), (32, 32) ...
	public int getPixelX() {
		return worldX*32;
	}
	
	public int getPixelY() {
		return worldY*32;
	}
	
	//get screen coordinates, these are from the Textured interface
	public int getX() {
		return getPixelX()-World.viewpoint.getPixelX()+GCanvas.WIDTH/2;
	}
	
	public int getY() {
		return getPixelY()-World.viewpoint.getPixelY()+GCanvas.HEIGHT/2;
	}
	
	public Texture getTexture() {
		return bp.getTexture();
	}
	
	public BlockBlueprint getBlueprint() {
		return bp;
	}
	
	public int getZ() {
		return 1000000001;
	}
	
}
