package engine.block;

import engine.graphics.Texture;

public class Stone extends BlockBlueprint {
	
	public static final Stone STONE = new Stone();	//relatively boring block... just a stone texture
	
	private Stone() {
		super(Texture.STONE);
	}
	
}
