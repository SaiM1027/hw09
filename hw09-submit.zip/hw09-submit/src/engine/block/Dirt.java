package engine.block;

import engine.graphics.Texture;

public class Dirt extends BlockBlueprint {
	
	public static final Dirt DIRT = new Dirt(); //Use this object whenever we want to create a dirt block
	
	private Dirt() {
		super(Texture.DIRT);
	}
	
}
