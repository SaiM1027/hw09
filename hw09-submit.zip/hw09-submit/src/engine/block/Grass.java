package engine.block;

import engine.graphics.Texture;

public class Grass extends BlockBlueprint {
	
	public static final Grass GRASS = new Grass(); //use this in the Block constructor to create grass blocks 
	
	private Grass() {
		super(Texture.GRASS);
	}
	
}
