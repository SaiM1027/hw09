package engine;

import java.awt.Point;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

//put all the input in one simple class-- has static methods below
public class Input implements MouseListener, MouseMotionListener, KeyListener {

	private static boolean keyPressed[] = new boolean[65536];
	private static boolean clicked;
	private static int mouseX, mouseY;

	public void keyTyped(KeyEvent e) {

	}

	public void keyPressed(KeyEvent e) {
		keyPressed[e.getKeyChar()] = true;
	}

	public void keyReleased(KeyEvent e) {
		keyPressed[e.getKeyChar()] = false;
	}

	public void mouseDragged(MouseEvent e) {

	}

	public void mouseMoved(MouseEvent e) {
		mouseX = e.getX();
		mouseY = e.getY();
	}

	public void mouseClicked(MouseEvent e) {

	}

	public void mousePressed(MouseEvent e) {
		clicked = true;
		mouseX = e.getX();
		mouseY = e.getY();
	}

	public void mouseReleased(MouseEvent e) {
		clicked = false;
	}

	public void mouseEntered(MouseEvent e) {

	}

	public void mouseExited(MouseEvent e) {

	}

	// supply input information based on the listeners that were already set up
	public static boolean isKeyPressed(char c) {
		return keyPressed[c];
	}
	
	private static long lastClick = System.nanoTime()-250000000;

	public static boolean isClicked() {
		boolean ret = clicked;
		if(System.nanoTime()-lastClick < 250000000) ret = false; //limit to 4 clicks per second
		if(ret) lastClick = System.nanoTime();
		
		clicked = false;
		return ret;
	}

	public static int getMouseX() {
		return mouseX;
	}

	public static int getMouseY() {
		return mouseY;
	}

	public static Point getMouseLocation() {
		return new Point(getMouseX(), getMouseY());
	}

}
