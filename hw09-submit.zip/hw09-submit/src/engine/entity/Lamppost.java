package engine.entity;

import engine.entity.inventory.ItemType;
import engine.entity.inventory.Metal;
import engine.graphics.Texture;
import engine.world.World;

public class Lamppost extends EntityBlueprint {
	
	public static final Lamppost LAMPPOST = new Lamppost();
	
	private Lamppost() {
		super(Texture.LAMPPOST, 0, Integer.MAX_VALUE);
	}
	
	//create light upon birth
	public void birth(Entity e) {
		World.getCurrentWorld().addLight(new Light(1, 1, 0.5f, e.x, e.y, 0.00003f, 0.05f, 0.5f));
	}

	//remove light once dead
	public void die(Entity e) {
		World.getCurrentWorld().removeLight(new Light(1, 1, 0.5f, e.x, e.y, 0.00003f, 0.05f, 0.5f));
	}
	
	//no movement
	public void moveCalculation(Entity e) {
		
	}
	
	//texture stays the same
	public void chooseTexture(Entity e) {
		
	}

	public ItemType killReward() {
		return Metal.METAL;
	}

	public int killRewardQuantity() {
		return 3;
	}

}
