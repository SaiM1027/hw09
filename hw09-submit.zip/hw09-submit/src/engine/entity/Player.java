package engine.entity;

import engine.Input;
import engine.Tick;
import engine.entity.inventory.Inventory;
import engine.entity.inventory.ItemType;
import engine.entity.inventory.Weapon;
import engine.entity.inventory.Wood;
import engine.graphics.GCanvas;
import engine.graphics.TextureAtlas;
import engine.world.World;
import util.Vector2f;

//the player that appears in the middle of the screen
public class Player extends EntityBlueprint {
	
	public static final Player PLAYER = new Player();
	
	private Player() {
		super(TextureAtlas.PLAYERDOWN.getTexture(0), 1.8f, 10);
	}
	
	public static int lastDirection = 0;
	static int dx[] = {-1, 0, 1, 0};
	static int dy[] = {0, -1, 0, 1};
	
	public void moveCalculation(Entity t) {
		t.getMovementVector().setX(0);
		t.getMovementVector().setY(0);//reset the direction vector
		if(Input.isKeyPressed('a')) { //use keyboard input to choose the player's direction
			t.getMovementVector().addX(-1);
			lastDirection = 0;
		}
		if(Input.isKeyPressed('d')) {
			t.getMovementVector().addX(1);
			lastDirection = 2;
		}
		if(Input.isKeyPressed('s')) {
			t.getMovementVector().addY(1);
			lastDirection = 3;
		}
		if(Input.isKeyPressed('w')) {
			t.getMovementVector().addY(-1);
			lastDirection = 1;
		}
		if(Input.isKeyPressed('f')) {
			World.getCurrentWorld().addEntity(new Entity(Spray.SPRAY, t.x, t.y-9));
		}
		t.getMovementVector().normalize(); //make it of unit length no matter what direction the player moves
		//calculates the direction the player moves in 
		
	}
	
	//nothing special happens when the player spawns
	public void birth(Entity e) {
		
	}

	public void die(Entity e) {
		
	}

	public void chooseTexture(Entity e) {
		int index = Tick.totalTicks/12%4; //which index of the animation cycle to use
		if(e.getMovementVector().getX() != 0) { //if the player is moving horizontally, use the textures that show the player moving left or right
			if(e.getMovementVector().getX() > 0) tex = TextureAtlas.PLAYERRIGHT.getTexture(index);
			else tex = TextureAtlas.PLAYERLEFT.getTexture(index);
		} else if(e.getMovementVector().getY() != 0) { //if the player is moving vertically, use the textures that depict the player moving up or down
			if(e.getMovementVector().getY() > 0) tex = TextureAtlas.PLAYERDOWN.getTexture(index);
			else tex = TextureAtlas.PLAYERUP.getTexture(index);
		}
	}

	public ItemType killReward() {
		return Wood.WOOD;
	}
	
	//game ends when player dies, so I just put a random value in here
	public int killRewardQuantity() {
		return 99999999;
	}

}
