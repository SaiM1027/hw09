package engine.entity;

import engine.Tick;
import engine.entity.inventory.ItemType;
import engine.entity.inventory.Metal;
import engine.graphics.TextureAtlas;
import engine.world.World;
import util.Vector2f;

public class Zombie extends EntityBlueprint {

	public static final Zombie ZOMBIE = new Zombie();
	
	private Zombie() {
		super(TextureAtlas.ZOMBIEDOWN.getTexture(0), 0.7f, 8);
	}

	public void chooseTexture(Entity e) {
		int index = Tick.totalTicks/16%4; //the index of the texture used in the animation cycle
		if(Math.abs(e.getMovementVector().getY()) >= 0.7f) { //if the zombie is moving more up than sideways, choose a vertical movement texture
			if(e.getMovementVector().getY() > 0) tex = TextureAtlas.ZOMBIEDOWN.getTexture(index);
			else tex = TextureAtlas.ZOMBIEUP.getTexture(index);
		} else if(e.getMovementVector().getX() != 0) { //if the zombie is moving sideways, choose a horizontal movement texture
			if(e.getMovementVector().getX() > 0) tex = TextureAtlas.ZOMBIERIGHT.getTexture(index);
			else tex = TextureAtlas.ZOMBIELEFT.getTexture(index);
		} 
	}

	public void birth(Entity e) {
		
	}

	public void die(Entity e) {
		
	}

	public void moveCalculation(Entity e) {
		Vector2f toPlayer = World.viewpoint.positionAsVector().add(World.viewpoint.getMovementVector().scale(6)).sub(e.positionAsVector());
		if(toPlayer.length() >= 400) {
			e.setMovementVector(Vector2f.ZERO);
		} else {
			e.setMovementVector(toPlayer); //walk directly towards the player
			e.getMovementVector().normalize(); //make the vector of unit length so that its length is constant no matter the distance between the zombie and player
			
			if(e.hitbox().intersects(World.viewpoint.hitbox())) {
				World.viewpoint.getHit(1, World.viewpoint.positionAsVector().sub(e.positionAsVector()));
			}
		}
	}

	public ItemType killReward() {
		return Metal.METAL;
	}

	public int killRewardQuantity() {
		return 8;
	}

}
