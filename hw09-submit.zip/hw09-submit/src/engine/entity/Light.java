package engine.entity;

//represents a Light that can be used by the World to light areas up
public class Light {
	
	private float r, g, b; //color channels
	private float x, y; //coordinates
	private float constantAttenuation, linearAttenuation, quadraticAttenuation; //used in calculating the light's drop-off over distance
	
	public Light(float r, float g, float b, float x, float y, float att0, float att1, float att2) {
		this.r = r;
		this.g= g;
		this.b = b;
		this.x = x;
		this.y =y;
		this.constantAttenuation = att2;
		this.linearAttenuation = att1;
		this.quadraticAttenuation = att0;
	}
	
	public Light(float x, float y, float att0, float att1, float att2) {
		this(1, 1, 1, x, y, att0, att1, att2);
	}
	
	public float getR() {
		return r;
	}

	public float getB() {
		return b;
	}

	public float getG() {
		return g;
	}

	public float getX() {
		return x;
	}

	public float getY() {
		return y;
	}

	public float getConstantAttenuation() {
		return constantAttenuation;
	}

	public float getLinearAttenuation() {
		return linearAttenuation;
	}

	public float getQuadraticAttenuation() {
		return quadraticAttenuation;
	}
	
	public void setR(float r) {
		this.r = r;
	}

	public void setB(float b) {
		this.b = b;
	}

	public void setG(float g) {
		this.g = g;
	}

	public void setX(float x) {
		this.x = x;
	}

	public void setY(float y) {
		this.y = y;
	}

	public void setConstantAttenuation(float constantAttenuation) {
		this.constantAttenuation = constantAttenuation;
	}

	public void setLinearAttenuation(float linearAttenuation) {
		this.linearAttenuation = linearAttenuation;
	}

	public void setQuadraticAttenuation(float quadraticAttenuation) {
		this.quadraticAttenuation = quadraticAttenuation;
	}
	
}
