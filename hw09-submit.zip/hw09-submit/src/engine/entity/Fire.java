package engine.entity;

import engine.Tick;
import engine.entity.inventory.ItemType;
import engine.graphics.Texture;
import engine.graphics.TextureAtlas;
import engine.world.World;
import util.Vector2f;

public class Fire extends EntityBlueprint {
	
	public static final Fire FIRE = new Fire(Texture.STONE, 5, 3);
	
	public Fire(Texture tex, float speed, int health) {
		super(tex, speed, health);
		fullBrightness = true;
	}

	public void chooseTexture(Entity e) {
		int index = (Tick.totalTicks/13 + e.getBlockX()*9%42 + e.getBlockY()%69)%4;
		tex = TextureAtlas.FIRE.getTexture(index);
	}
	
	private int numFires = 0;
	
	public void birth(Entity e) {
		numFires++;
		for(Entity ent : World.getCurrentWorld().allEntities()) {
			if(e.hitbox().intersects(ent.hitbox())) {
				if(ent.getBlueprint().equals(Tree.TREE) || ent.getBlueprint().equals(TreeBurnHalf.TREE_BURN_HALF) || ent.getBlueprint().equals(TreeSapling.TREE_SAPLING)) 
					ent.setRenderedWithFullBrightness(true);
				if(!ent.getBlueprint().equals(Fire.FIRE))
					ent.getHit(4, Vector2f.ZERO);
				if(ent.getBlueprint().equals(Tree.TREE) || ent.getBlueprint().equals(TreeBurnHalf.TREE_BURN_HALF) || ent.getBlueprint().equals(TreeSapling.TREE_SAPLING))
					e.getHit(-9, Vector2f.ZERO);
			}
		}
	}
	
	private int fire_limit = 1024;
	
	public void die(Entity e) {
		numFires--;
		boolean spawnMore = false;
		if(numFires < fire_limit && Math.random() < (1-(numFires*1.0/fire_limit))) {
			for(Entity ent : World.getCurrentWorld().allEntities()) {
				if(e.hitbox().intersects(ent.hitbox())) {
					if(ent.getBlueprint().equals(Tree.TREE) || ent.getBlueprint().equals(TreeBurnHalf.TREE_BURN_HALF) || ent.getBlueprint().equals(TreeSapling.TREE_SAPLING)) {
						spawnMore = true;
					}
					if(ent.getBlueprint().equals(Spray.SPRAY)) {
						spawnMore = false;
						World.getCurrentWorld().score++;
						break;
					}
				}
			}
		}
		if(spawnMore && e.getHealth() > -10) for(int i = 0; i < 8*(1-(numFires*1.0/fire_limit)); i++) {
			World.getCurrentWorld().addEntity(new Entity(FIRE, e.getTrueX()+(float)Math.random()*196-98, e.getTrueY()+(float)Math.random()*196-98));
		}
	}

	public ItemType killReward() {
		return null;
	}

	public int killRewardQuantity() {
		return 0;
	}
	
	public boolean isDead(Entity e) {
		if(super.isDead(e)) return true;
		return false;
	}

	public void moveCalculation(Entity e) {
		if(Math.random() < 0.02) e.getHit(1, Vector2f.ZERO);
	}

}
