package engine.entity;

import engine.entity.inventory.ItemType;
import engine.entity.inventory.Metal;
import engine.graphics.Texture;
import engine.world.World;

public class Lamp extends EntityBlueprint {
	
	public static final Lamp LAMP = new Lamp();
	
	private Lamp() {
		super(Texture.LAMP, 0, Integer.MAX_VALUE);
	}
	
	//create a light when spawned
	public void birth(Entity e) {
		World.getCurrentWorld().addLight(new Light(1, 1, 0.5f, e.x, e.y, 0.00004f, 0.0008f, 0.4f));
	}

	//remove that same light
	public void die(Entity e) {
		World.getCurrentWorld().removeLight(new Light(1, 1, 0.5f, e.x, e.y, 0.00004f, 0.0008f, 0.4f));
	}

	//no movement
	public void moveCalculation(Entity e) {
		
	}
	
	public ItemType killReward() {
		return Metal.METAL;
	}
	
	public int killRewardQuantity() {
		return 2;
	}
	
	//texture stays the same... no need to use this method
	public void chooseTexture(Entity e) {
		
	}

}
