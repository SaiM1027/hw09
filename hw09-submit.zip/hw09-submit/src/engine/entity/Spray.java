package engine.entity;

import engine.entity.inventory.ItemType;
import engine.graphics.Texture;
import engine.world.World;
import util.Vector2f;

public class Spray extends EntityBlueprint {

	public static final Spray SPRAY = new Spray();
	
	public Spray() {
		super(Texture.SPRAY, 2.2f, 1);
	}

	public void chooseTexture(Entity e) {
		
	}

	public void birth(Entity e) {
		
	}

	public void die(Entity e) {
		
	}
	
	public boolean isDead(Entity e) {
		if(e.positionAsVector().sub(World.viewpoint.positionAsVector()).length() > 36) return true;
		return false;
	}

	public ItemType killReward() {
		return null;
	}

	public int killRewardQuantity() {
		return 0;
	}
	
	public void moveCalculation(Entity e) {
		Vector2f direction = new Vector2f((float) Math.cos(Math.toRadians(e.birthDate*69.420%360)), (float) Math.sin(Math.toRadians(e.birthDate*69.420%360)));
		direction.normalize();
		
		for(Entity ent : World.getCurrentWorld().allEntities()) {
			if(ent.getBlueprint().equals(Fire.FIRE))
				if(e.hitbox().intersects(ent.hitbox())) {
					ent.getHit(99, Vector2f.ZERO);
			}
		}
		
		e.x += direction.getX()*this.getSpeed();
		e.y += direction.getY()*this.getSpeed();
	}

}
