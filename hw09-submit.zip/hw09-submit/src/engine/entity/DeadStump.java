package engine.entity;

import engine.block.Block;
import engine.block.Dirt;
import engine.block.Grass;
import engine.entity.inventory.ItemType;
import engine.entity.inventory.Wood;
import engine.graphics.Texture;
import engine.world.World;

public class DeadStump extends EntityBlueprint {
	
	public static final DeadStump TREE_STUMP = new DeadStump();

	private DeadStump() {
		super(Texture.TREE_STUMP, 0, 6);
	}

	public void moveCalculation(Entity e) {
		
	}

	public void birth(Entity e) {
		
	}
	
	public boolean isDead(Entity e) {
		if(super.isDead(e)) return true; //use the default isDead method
		Block currentBlock = World.getCurrentWorld().getBlock(e.getBlockX(), e.getBlockY());
		//also die if the tree is not on grass or dirt
		if(!(currentBlock.getBlueprint().equals(Grass.GRASS) || currentBlock.getBlueprint().equals(Dirt.DIRT))) return true;
		return false;
	}
	
	public void die(Entity e) {

	}
	
	public void chooseTexture(Entity e) {
		
	}
	
	public ItemType killReward() {
		return Wood.WOOD;
	}
	
	public int killRewardQuantity() {
		return 2;
	}
	
}
