package engine.entity;

import engine.block.Block;
import engine.block.Dirt;
import engine.block.Grass;
import engine.entity.inventory.ItemType;
import engine.entity.inventory.Wood;
import engine.graphics.Texture;
import engine.world.World;
import util.Vector2f;

public class TreeSapling extends EntityBlueprint {
	
	public static final TreeSapling TREE_SAPLING = new TreeSapling();

	private TreeSapling() {
		super(Texture.TREE_SAPLING, 0, 1);
	}
	
	public void moveCalculation(Entity e) {
		//"grow" into a tree
		if(Math.random() < 0.0001) {
			World.getCurrentWorld().addEntity(new Entity(Tree.TREE, e.getTrueX(), e.getTrueY())); //spawn a tree at this location
			e.getHit(99, Vector2f.ZERO); //take 99 damage to remove the sapling
		}
		//sapling gets replaced by a tree... looks like the sapling is "growing"
	}
	
	//same criteria as the tree for death
	public boolean isDead(Entity e) {
		if(super.isDead(e)) return true;
		Block currentBlock = World.getCurrentWorld().getBlock(e.getBlockX(), e.getBlockY());
		if(!(currentBlock.getBlueprint().equals(Grass.GRASS) || currentBlock.getBlueprint().equals(Dirt.DIRT))) return true;
		return false;
	}

	public void birth(Entity e) {
		
	}

	public void die(Entity e) {
		
	}
	
	public void chooseTexture(Entity e) {
		
	}

	public ItemType killReward() {
		return Wood.WOOD;
	}

	public int killRewardQuantity() {
		return 1;
	}

}
