package engine.entity;

import engine.block.Block;
import engine.block.Dirt;
import engine.block.Grass;
import engine.entity.inventory.ItemType;
import engine.entity.inventory.Wood;
import engine.graphics.Texture;
import engine.world.World;
import util.Vector2f;

public class Tree extends EntityBlueprint {
	
	public static final Tree TREE = new Tree();
	
	private Tree() {
		super(Texture.TREE, 0, 12);
	}

	public void moveCalculation(Entity e) {
		if(Math.random() < 0.000001) { //spawn new baby trees around it at times
			float newX = e.x + (float) ((Math.random()-0.5)*200);
			float newY = e.y + (float) ((Math.random()-0.5)*200);
			World.getCurrentWorld().addEntity(new Entity(TreeSapling.TREE_SAPLING, newX, newY));
			e.getHit(1, Vector2f.ZERO); //don't let a tree live an infinite life... take damage when it spawns offspring
		}
	}
	
	public boolean isDead(Entity e) {
		if(super.isDead(e)) return true; //use the default isDead method
		Block currentBlock = World.getCurrentWorld().getBlock(e.getBlockX(), e.getBlockY());
		//also die if the tree is not on grass or dirt
		if(!(currentBlock.getBlueprint().equals(Grass.GRASS) || currentBlock.getBlueprint().equals(Dirt.DIRT))) return true;
		return false;
	}

	public void birth(Entity e) {
		World.getCurrentWorld().removeLight(new Light(e.x, e.y, 0.07f, 0.00001f, 0.2f)); //cast a shadow by "removing" a light
	}
	
	//spawn a tree stump where this tree dies
	public void die(Entity e) {
		World.getCurrentWorld().addEntity(new Entity(TreeBurnHalf.TREE_BURN_HALF, e.getTrueX(), e.getTrueY()));
		World.getCurrentWorld().addLight(new Light(e.x, e.y, 0.07f, 0.00001f, 0.2f)); //remove the shadow by "adding" the light
	}
	
	public void chooseTexture(Entity e) {
		
	}

	public ItemType killReward() {
		return Wood.WOOD;
	}

	public int killRewardQuantity() {
		return 24;
	}

}
