package engine.entity;

import engine.entity.inventory.ItemType;
import engine.graphics.Texture;
import engine.world.World;
import util.BoundsChecker;

//the attributes that can be given to an Entity
public abstract class EntityBlueprint {
	
	protected Texture tex;
	private float speed;
	private int health;
	protected boolean fullBrightness = false;
	
	public EntityBlueprint(Texture tex, float speed, int health) {
		this.tex = tex;
		this.speed = speed;
		this.health = health;
	}
	
	public int getStartingHealth() {
		return health;
	}
	
	public abstract void chooseTexture(Entity e); //may be used to choose textures from animation loops
	
	//the texture that should be used to render the entity to the screen
	public Texture getTexture() {
		return tex;
	}
	
	public float getSpeed() {
		return speed;
	}
	
	public boolean renderedWithFullBrightness() {
		return fullBrightness;
	}
	
	public abstract void birth(Entity e); //called once upon an entity spawning
	public abstract void die(Entity e); //called once upon an entity's death
	
	public abstract ItemType killReward();
	public abstract int killRewardQuantity();
	
	//the default criteria for an entity to die
	public boolean isDead(Entity e) {
		if(!BoundsChecker.inBounds(0, World.getCurrentWorld().getWidth()*32, e.getPixelX()) || //tests for the entity being INSIDE the world
				!BoundsChecker.inBounds(0, World.getCurrentWorld().getHeight()*32, e.getPixelY())) return true;
		return e.getHealth() <= 0; //tests for the entity having enough health
	}
	
	public abstract void moveCalculation(Entity e); //any calculations first happen here
	
}
