package engine.entity;

import java.awt.Rectangle;

import engine.Tick;
import engine.graphics.GCanvas;
import engine.graphics.Texture;
import engine.graphics.Textured;
import engine.world.World;
import util.Vector2f;

//all entities should do/have these things:
public class Entity implements Textured {
	
	protected float x, y;
	protected EntityBlueprint eb;
	private int health;
	protected int birthDate;
	protected Vector2f movement = new Vector2f(0, 0);
	
	protected boolean renderedWithFullBrightness;
	
	public Entity(EntityBlueprint eb, float x, float y) {
		this.x = x;
		this.y = y;
		this.eb = eb;
		health = eb.getStartingHealth();
		birthDate = Tick.totalTicks;
		renderedWithFullBrightness = eb.renderedWithFullBrightness();
	}
	
	//when loading entities from the file, they may have a different health than their starting health... use this to
	//setup entities who have already been damaged
	public Entity(EntityBlueprint eb, float x, float y, int health) {
		this.x = x;
		this.y = y;
		this.eb = eb;
		this.health = health;
		birthDate = Tick.totalTicks;
		renderedWithFullBrightness = eb.renderedWithFullBrightness();
	}
	
	public void setRenderedWithFullBrightness(boolean b) {
		renderedWithFullBrightness = b;
	}
	
	public boolean renderedWithFullBrightness() {
		return renderedWithFullBrightness;
	}
	
	//the backing coordinates behind entities are floats... this is so that we can have fractional movement
	public float getTrueX() {
		return x;
	}
	
	public float getTrueY() {
		return y;
	}
	
	//these are the entity's screen coordinates, determined by the location of the Player
	public int getX() {
		return getPixelX()-World.viewpoint.getPixelX()-getTexture().WIDTH/2 + GCanvas.WIDTH/2;
	}
	
	public int getY() {
		return getPixelY()-World.viewpoint.getPixelY()-getTexture().HEIGHT + GCanvas.HEIGHT/2;
	}
	
	//these are the entity's precise coordinates, as integers, so that they can be given location as pixels (pixels have integer coords)
	public int getPixelX() {
		return Math.round(x);
	}
	
	public int getPixelY() {
		return Math.round(y);
	}
	
	//this is the block that the entity occupies... the world is tiled by 32x32 blocks, so we just divide by 32
	public int getBlockX() {
		return getPixelX()/32;
	}
	
	public int getBlockY() {
		return getPixelY()/32;
	}
	
	//entity's current health
	public int getHealth() {
		return Math.max(health, 0);
	}
	
	//whether or not an entity should be dead... different cases for different entities, so we use the entity blueprint for this
	public boolean isDead() {
		return eb.isDead(this);
	}
	
	public Texture getTexture() {
		eb.chooseTexture(this); //this method may be used by some entities if there are animation loops
		return eb.getTexture(); 
	}
	
	//remove health, and get knocked back
	public void getHit(int damage, Vector2f hitDirection) {
		health -= damage; //subtract health
		
		hitDirection.normalize(); //make vector of unit length for consistent results no matter the distance between the hitter and the hit
		//temp
		x += hitDirection.getX()*eb.getSpeed()*15;
		y += hitDirection.getY()*eb.getSpeed()*15;
		//temp
	}
	
	public Vector2f positionAsVector() {
		return new Vector2f(x, y);
	}
	
	public Rectangle hitbox() {
		Texture curr = getTexture();
		return new Rectangle(getPixelX()-3*curr.WIDTH/8, getPixelY()-curr.HEIGHT/2, curr.WIDTH*3/4, curr.HEIGHT/2);
	}
	
	public float hitRadius() {
		Rectangle hitbox = hitbox();
		return (float) (Math.sqrt(hitbox.getWidth()*hitbox.getWidth() + hitbox.getHeight()*hitbox.getHeight())*2.5);
	}
	
	public Vector2f centerOfHitbox() {
		Rectangle hitbox = hitbox();
		return new Vector2f((float) (hitbox.x+hitbox.getWidth()/2), (float) (hitbox.y+hitbox.getHeight()/2));
	}
	
	//use entity blueprint to make movement calculations
	public void move() {
		eb.moveCalculation(this);
		x += movement.getX()*eb.getSpeed();
		y += movement.getY()*eb.getSpeed();
	}
	
	public EntityBlueprint getBlueprint() {
		return eb;
	}
	
	//called once upon death
	public void die() {
		eb.die(this);
	}
	
	//called once upon being spawned
	public void birth() {
		eb.birth(this);
	}
	
	public int getZ() {
		return 0;
	}
	
	public Vector2f getMovementVector() {
		return movement;
	}
	
	public void setMovementVector(Vector2f mov) {
		movement = mov;
	}

}
