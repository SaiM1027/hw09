package engine.entity.inventory;

import engine.graphics.Texture;

public class Wood extends ItemType {
	
	public static final Wood WOOD = new Wood();
	
	private Wood() {
		super(Texture.WOOD);
	}
	
}
