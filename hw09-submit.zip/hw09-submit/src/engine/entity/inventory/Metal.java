package engine.entity.inventory;

import engine.graphics.Texture;

public class Metal extends ItemType {
	
	public static final Metal METAL = new Metal();

	protected Metal() {
		super(Texture.METAL);
	}

}
