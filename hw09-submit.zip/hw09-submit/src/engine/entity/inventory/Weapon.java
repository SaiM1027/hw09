package engine.entity.inventory;

import engine.graphics.Texture;

public class Weapon extends ItemType {
	
	public static final Weapon WEAPON_ONE = new Weapon(Texture.WEAPON1, 2);
	public static final Weapon WEAPON_TWO = new Weapon(Texture.WEAPON2, 4);
	public static final Weapon WEAPON_THREE = new Weapon(Texture.WEAPON3, 8);
	
	private int damage;
	
	protected Weapon(Texture tex, int damage) {
		super(tex);
		this.damage = damage;
	}
	
	public int getDamage() {
		return damage;
	}
	
}
