package engine.entity.inventory;

import engine.graphics.Texture;

//represents a type of item
public abstract class ItemType {
	
	private Texture tex;
	
	protected ItemType(Texture tex) {
		this.tex = tex;
	}
	
	public Texture getTexture() {
		return tex;
	}
	
}
