package engine.entity.inventory;

import java.util.HashMap;

public class ItemManager {
	
	private HashMap<String, ItemType> stringToItem = new HashMap<String, ItemType>();
	private HashMap<ItemType, String> itemToString = new HashMap<ItemType, String>();
	
	private ItemManager() {
		addStringAndItem("W", Wood.WOOD);
		addStringAndItem("M", Metal.METAL);
		addStringAndItem("1", Weapon.WEAPON_ONE);
		addStringAndItem("2", Weapon.WEAPON_TWO);
		addStringAndItem("3", Weapon.WEAPON_THREE);
	}
	
	public void addStringAndItem(String id, ItemType item) {
		stringToItem.put(id, item);
		itemToString.put(item, id);
	}
	
	public ItemType getItemType(String id) {
		return stringToItem.get(id);
	}
	
	public String getIDString(ItemType item) {
		return itemToString.get(item);
	}
	
}
