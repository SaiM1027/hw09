package engine.entity.inventory;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;

import engine.Main;
import engine.graphics.GCanvas;
import engine.graphics.Texture;
import engine.graphics.TextureAtlas;
import engine.graphics.Textured;

public class Inventory {
	
	public static final Inventory INVENTORY = new Inventory(Main.renderer.renderCollection()); //there is only one inventory (the player's), so I just create one here
	
	
	//should have a slot for: wood, metal, weapon1, weapon2, weapon3
	private ItemQuantity[] slots; //these are the items that fill the inventory slots
	private HashMap<ItemType, Integer> itemToSlot; //input: ItemType | output: the slot that the item should go in
	private Collection<Textured> inventoryRenderList;
	
	public Inventory(Collection<Textured> renderList) {
		inventoryRenderList = renderList;
		
		itemToSlot = new HashMap<ItemType, Integer>();
		itemToSlot.put(Wood.WOOD, 0);
		itemToSlot.put(Metal.METAL, 1);
		itemToSlot.put(Weapon.WEAPON_ONE, 2);
		itemToSlot.put(Weapon.WEAPON_TWO, 3);
		itemToSlot.put(Weapon.WEAPON_THREE, 4);
		
		slots = new ItemQuantity[5];
		slots[0] = new ItemQuantity(-128, Wood.WOOD);
		slots[1] = new ItemQuantity(-64, Metal.METAL);
		slots[2] = new ItemQuantity(0, Weapon.WEAPON_ONE);
		slots[3] = new ItemQuantity(64, Weapon.WEAPON_TWO);
		slots[4] = new ItemQuantity(128, Weapon.WEAPON_THREE);
	}
	
	public void addIconsToRenderList() {
		for(int i = 0; i < 5; i++) {
			inventoryRenderList.add(slots[i]);
		}
	}
	
	public void removeIconsFromRenderList() {
		for(int i = 0; i < 5; i++) inventoryRenderList.remove(slots[i]);
		for(int i = 0; i < 5; i++) inventoryRenderList.removeAll(slots[i].digits);
	}
	
	public void clearInventory() {
		for(int i = 0; i < 5; i++) {
			slots[i].changeQuantity(-slots[i].quantity);
		}
	}
	
	public void addItems(ItemType itemType, int quantity) {
		int index = itemToSlot.get(itemType);
		slots[index].changeQuantity(quantity);
		
		//update render list as well
		inventoryRenderList.removeAll(slots[index].getDigitTextures());
		slots[index].reCalculateDigitTextures();
		inventoryRenderList.addAll(slots[index].getDigitTextures());
	}
	
	public void addItems(int index, int quantity) {
		slots[index].changeQuantity(quantity);
		
		//update render list as well
		inventoryRenderList.removeAll(slots[index].getDigitTextures());
		slots[index].reCalculateDigitTextures();
		inventoryRenderList.addAll(slots[index].getDigitTextures());
	}
	
	public int getItemCount(int index) {
		return slots[index].quantity;
	}
	
	public int getItemCount(ItemType item) {
		return slots[itemToSlot.get(item)].quantity;
	}
	
	private static class ItemQuantity implements Textured {
		
		private ItemType item;
		private int quantity;
		private int offsetFromCenterOfScreen;
		private List<Digit> digits;
		
		public ItemQuantity(int offsetFromCenterOfScreen, ItemType item) {
			this.item = item;
			this.quantity = 0;
			this.offsetFromCenterOfScreen = offsetFromCenterOfScreen;
			digits = new ArrayList<Digit>();
		}
		
		public void changeQuantity(int change) {
			quantity += change;
		}
		
		public int getX() {
			return GCanvas.WIDTH/2-16+offsetFromCenterOfScreen;
		}
		
		public int getY() {
			return GCanvas.HEIGHT-96;
		}
		
		public Texture getTexture() {
			return item.getTexture();
		}
		
		public void reCalculateDigitTextures() {
			digits.clear();
			List<Integer> d = new ArrayList<Integer>();
			int temp = quantity;
			if(temp == 0) digits.add(new Digit(getX()+22, getY()+20, TextureAtlas.NUMERALS.getTexture(0)));
			
			while(temp != 0) {
				d.add(temp%10);
				temp /= 10;
			}
			for(int i = 0; i < d.size(); i++) {
				digits.add(new Digit(getX()-(i+1)*10+32, getY()+20, TextureAtlas.NUMERALS.getTexture(d.get(i))));
			}
		}
		
		public List<Digit> getDigitTextures() {
			return digits;
		}
		
		public int getZ() {
			return 10;
		}
		
	}
	
	private static class Digit implements Textured {
		
		private int x, y;
		private Texture tex;
		
		public Digit(int x, int y, Texture dig) {
			this.x = x;
			this.y = y;
			this.tex = dig;
		}
		
		public int getX() {
			return x;
		}

		public int getY() {
			return y;
		}

		public Texture getTexture() {
			return tex;
		}
		
		public int getZ() {
			return 20;
		}
		
	}
	
}
