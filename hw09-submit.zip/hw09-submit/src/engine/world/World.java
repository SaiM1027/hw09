package engine.world;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

import engine.block.Block;
import engine.entity.Entity;
import engine.entity.Light;
import util.BoundsChecker;

public class World {
	
	private static World currentWorld;
	
	public static final String dirToWorldSaveFolder = System.getProperty("user.dir") + "/GN/maps";
	
	private Block[][] map; //the tiles
	private int WIDTH, HEIGHT; //width and height in blocks
	public static Entity viewpoint; //where the world should be rendered from
	private float[][] brightnessR, brightnessG, brightnessB; //the lighting intensities in the three color channels
	public long startTime;
	
	private List<Entity> ents; //all entities
	
	private WorldGenerator wg; //the chosen world generator... used in world generation
	
	public boolean wildfire0shown = false, wildfire1shown = false, wildfire2shown = false,
			wildfire3shown = false, wildfire4shown = false;
	
	public int score;
	
	public World(WorldGenerator wg) {
		WIDTH = wg.getWidth();
		HEIGHT = wg.getHeight();
		ents = new ArrayList<Entity>();
		brightnessR = new float[WIDTH][HEIGHT];
		brightnessG = new float[WIDTH][HEIGHT];
		brightnessB = new float[WIDTH][HEIGHT];
		this.wg = wg;
		worldGen();
		startTime = System.currentTimeMillis();
	}
	
	//uses lighting calculations to add light intensity to each of the three color channels
	public void addLight(Light l) {
		for(int i = 0; i < WIDTH; i++) {
			for(int j = 0; j < HEIGHT; j++) {
				int centerOfBlockX = map[i][j].getPixelX() + 16;
				int centerOfBlockY = map[i][j].getPixelY() + 16;
				float dist = (float) Math.sqrt(Math.pow(centerOfBlockX-l.getX(), 2) + Math.pow(centerOfBlockY - l.getY(), 2));
				if(dist >= 1000) continue;
				float attenuation = dist*dist*l.getQuadraticAttenuation() + dist*l.getLinearAttenuation() + l.getConstantAttenuation();
				if(attenuation <= 0.00000001) continue;
				
				brightnessR[i][j] += l.getR()/attenuation;
				brightnessG[i][j] += l.getG()/attenuation;
				brightnessB[i][j] += l.getB()/attenuation;
			}
		}
	}
	
	//uses lighting calculations to remove light intensity from each of the three color channels
	public void removeLight(Light l) {
		for(int i = 0; i < WIDTH; i++) {
			for(int j = 0; j < HEIGHT; j++) {
				int centerOfBlockX = map[i][j].getPixelX() + 16;
				int centerOfBlockY = map[i][j].getPixelY() + 16;
				float dist = (float) Math.sqrt(Math.pow(centerOfBlockX-l.getX(), 2) + Math.pow(centerOfBlockY - l.getY(), 2));
				float attenuation = dist*dist*l.getQuadraticAttenuation() + dist*l.getLinearAttenuation() + l.getConstantAttenuation();
				if(attenuation <= 0.00000001) continue;
				
				brightnessR[i][j] -= l.getR()/attenuation;
				brightnessG[i][j] -= l.getG()/attenuation;
				brightnessB[i][j] -= l.getB()/attenuation;
			}
		}
	}
	
	public void addEntity(Entity e) {
		toAdd.add(e);
	}
	
	public void removeEntity(Entity e) {
		toRemove.remove(e);
	}
	
	//save world
	public void saveWorld() {
		wg.saveWorld(this);
	}
	
	//generate the map from using the WorldGenerator. The first entity is the viewpoint entity.
	private void worldGen() {
		map = new Block[WIDTH][HEIGHT];
		for(int i = 0; i < WIDTH; i++) {
			for(int j = 0; j < HEIGHT; j++) {
				map[i][j] = new Block(i, j, wg.getBlock(i, j));
			}
		}
		
		for(Entity e : wg.getStartingEnts()) addEntity(e);
		wildfire0shown = wg.getNotificationStatuses().get(0);
		wildfire1shown = wg.getNotificationStatuses().get(1);
		wildfire2shown = wg.getNotificationStatuses().get(2);
		wildfire3shown = wg.getNotificationStatuses().get(3);
		wildfire4shown = wg.getNotificationStatuses().get(4);
		score = wg.getScore();
		setViewpoint(wg.getPlayer());
	}
	
	private static Comparator<Entity> byY = new Comparator<Entity>() { //the comparator that sorts entities from back to front
		public int compare(Entity o1, Entity o2) {
			return o1.getPixelY()-o2.getPixelY();
		}
	};
	
	//sort entities from back to front, so that they get rendered sort of like by the Painter's Algorithm
	public void sortEntitiesByY() {
		Collections.sort(ents, byY);
	}
	
	public List<Entity> allEntities() {
		return ents;
	}
	
	private Queue<Entity> toRemove = new LinkedList<Entity>();
	private Queue<Entity> toAdd = new LinkedList<Entity>();
	
	public void moveAllEntities() {
		for(Entity e : ents) {
			e.move();
			if(e.isDead()) toRemove.add(e);
		}
		while(!toRemove.isEmpty()) {
			toRemove.peek().die();
			ents.remove(toRemove.remove());
		}
		while(!toAdd.isEmpty()) {
			toAdd.peek().birth();
			ents.add(toAdd.remove());
		}
		this.sortEntitiesByY();
	}
	
	public static void setViewpoint(Entity e) { //screen should be centered around this entity
		viewpoint = e;
	}
	
	public int getWidth() {
		return WIDTH;
	}
	
	public int getHeight() {
		return HEIGHT;
	}
	
	public Block getBlock(int x, int y) {
		return map[x][y];
	}
	
	//get red intensity of block (i, j)
	public float getRed(int i, int j) {
		if(!BoundsChecker.inBounds(0, WIDTH, i) || !BoundsChecker.inBounds(0, HEIGHT, j)) return 0;
		return Math.min(Math.max(0.2f, brightnessR[i][j]), 6);
	}
	
	//get blue intensity of block (i, j)
	public float getBlue(int i, int j) {
		if(!BoundsChecker.inBounds(0, WIDTH, i) || !BoundsChecker.inBounds(0, HEIGHT, j)) return 0;
		return Math.min(Math.max(0.2f, brightnessB[i][j]), 6);
	}
	
	//get green intensity of block (i, j)
	public float getGreen(int i, int j) {
		if(!BoundsChecker.inBounds(0, WIDTH, i) || !BoundsChecker.inBounds(0, HEIGHT, j)) return 0;
		return Math.min(Math.max(0.2f, brightnessG[i][j]), 6);
	}
	
	//sets the current, active world
	public static void setWorld(World w) {
		currentWorld = w;
	}
	
	public static World getCurrentWorld() {
		return currentWorld;
	}
	
}
