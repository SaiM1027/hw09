package engine.world;

import java.util.List;

import engine.block.BlockBlueprint;
import engine.entity.Entity;

//classes that implement this interface may be used by the World class to generate worlds
public interface WorldGenerator {
	
	public BlockBlueprint getBlock(int i, int j);
	public void saveWorld(World w);
	public List<Entity> getStartingEnts();
	public Entity getPlayer();
	public int getWidth();
	public int getHeight();
	public List<Boolean> getNotificationStatuses();
	public int getScore();
	
}
