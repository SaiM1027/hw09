package engine;

public class Tick {
	
	private int currentState = 0;	//0 menu, 1 roam world
	private GameO game;
	
	public static int totalTicks = 0; //how many ticks have elapsed since the beginning of execution... may be used in timing animations
	
	public Tick(GameO game) {
		this.game = game;
		game.enterState(currentState);
	}
	
	public int getState() {
		return currentState;
	}
	
	public void changeState(int state) {
		game.exitState(currentState);
		currentState = state;
		game.enterState(state);
	}

	//gets run in consistent intervals
	public void run() {
		totalTicks++;
		game.loop(currentState);
	}

}
