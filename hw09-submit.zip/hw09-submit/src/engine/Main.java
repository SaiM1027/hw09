package engine;

import engine.graphics.Frame;

public class Main {
	
	public static final int TICKS = 64;//number of ticks per second
	public static Tick ticker;
	public static Render renderer;
	
	//this is called by the driver class when the programmer wants to start the game
	public static void start(GameO game) {
		renderer = new Render(game.title); //handles rendering
		ticker = new Tick(game); //handles whatever happens in consistent intervals
		
		long old = System.nanoTime(); //keeps track of the last time the while loop ran
		double delta = 1000000000.0 / TICKS;	//time between each tick
		
		long oldM = System.currentTimeMillis(); //keeps track of the last time frame and tick numbers were printed
		int tps = 0, fps = 0;
		
		while(true) {
			if(Frame.closeRequested) { //exit button hit
				ticker.changeState(-1);
				System.exit(0);
			}
			while(System.nanoTime() - old >= delta) {//tick when enough time has passed by
				old += delta;
				ticker.run();
				tps++;
			}
			if(System.currentTimeMillis() - oldM >= 1000) {//print statistics about frames and ticks per second
				System.out.println("Ticks: " + tps);
				System.out.println("Frames: " + fps);
				tps = 0;
				fps = 0;
				oldM += 1000;
			}
			//render as often as possible-- that's why it's directly in the while loop
			renderer.run();
			fps++;
		}

	}
}
