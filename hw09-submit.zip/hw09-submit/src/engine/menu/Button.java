package engine.menu;

import java.awt.Point;
import java.awt.Rectangle;

import engine.graphics.Texture;
import engine.graphics.Textured;

//custom-implemented button
//MenuSetup class will call these methods as long as the Button is added to the MenuSetup
public abstract class Button implements Textured {
	
	private Rectangle hitbox;
	private Texture normal;
	private Texture hovered;
	private boolean isHovered;
	
	public Button(int x, int y, int width, int height, Texture normal, Texture hovered) {
		hitbox = new Rectangle(x, y, width, height);
		this.normal = normal;
		this.hovered = hovered;
	}
	
	public int getX() {
		return hitbox.x;
	}
	
	public int getY() {
		return hitbox.y;
	}
	
	public Texture getTexture() {
		return isHovered ? hovered : normal;
	}
	
	//sets this button to be hovered or not based on the location of the mouse
	public void setHovered(Point mouseCoords) {
		isHovered = hitbox.contains(mouseCoords);
	}
	
	//same method as above but uses two ints rather than a Point
	public void setHovered(int x, int y) {
		isHovered = hitbox.contains(x, y);
	}
	
	public Texture getNormalStateTexture() {
		return normal;
	}
	
	public Texture getHoveredTexture() {
		return hovered;
	}
	
	public boolean contains(Point coord) {
		return hitbox.contains(coord);
	}
	
	public abstract void clickAction();
	
	public int getZ() {
		return 1000000000;
	}
}
