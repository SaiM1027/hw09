package engine.menu;

import java.awt.Point;
import java.util.HashSet;
import java.util.Set;

import engine.Main;
import engine.entity.Entity;
import engine.entity.Lamp;
import engine.entity.inventory.Inventory;
import engine.entity.inventory.Metal;
import engine.entity.inventory.Weapon;
import engine.entity.inventory.Wood;
import engine.graphics.Texture;
import engine.world.World;
import game.Game;

public class MenuSetup { //place to handle all the buttons in a menu
	
	public static final MenuSetup mainMenu = new MenuSetup(
			  new Button(132, 82, 80, 80, Texture.SAVE1, Texture.SAVE1_HOVERED) {
				  public void clickAction() {
					Main.ticker.changeState(1);
				  }
			  } ,
			  new Button(344, 82, 80, 80, Texture.SAVE2, Texture.SAVE2_HOVERED) {
				  public void clickAction() {
					Main.ticker.changeState(2);
				  }
			  } ,
			  new Button(556, 82, 80, 80, Texture.SAVE3, Texture.SAVE3_HOVERED) {
				  public void clickAction() {
					Main.ticker.changeState(4);
				  }
			  } ,
			  new Button(132, 246, 80, 80, Texture.SAVE4, Texture.SAVE4_HOVERED) {
				  public void clickAction() {
					Main.ticker.changeState(5);
				  }
			  } ,
			  new Button(344, 246, 80, 80, Texture.SAVE5, Texture.SAVE5_HOVERED) {
				  public void clickAction() {
					Main.ticker.changeState(6);
				  }
			  } ,
			  new Button(556, 246, 80, 80, Texture.SAVE6, Texture.SAVE6_HOVERED) {
				  public void clickAction() {
					Main.ticker.changeState(7);
				  }
			  } ,
			new Button(284, 411, 200, 82, Texture.HELP, Texture.HELP_HOVERED) {
				public void clickAction() {
					Main.ticker.changeState(3);
				}
			}
	);
	
	public static final MenuSetup backButton = new MenuSetup(
			new Button(284, 411, 200, 82, Texture.BACK, Texture.BACK_HOVERED) {
				public void clickAction() {
					Main.ticker.changeState(0);
				}
			}
	);
	
	public static final MenuSetup helpScreen = new MenuSetup(
			new Button(84, 30, 600, 330, Texture.HELPMENU, Texture.HELPMENU) {
				public void clickAction() {
					
				}
			}
	);
	
//	public static final MenuSetup wildfireAlert = new MenuSetup(
//			new Button(558, 5, 200, 566, Texture.WILDFIRE0, Texture.WILDFIRE0_HOVERED) {
//				public void clickAction() {
//					TSurvival.alertsToRemove.add(wildfireAlert);
//				}
//			}
//	);
//	
//	public static final MenuSetup wildfireAlert2 = new MenuSetup(
//			new Button(558, 5, 200, 566, Texture.WILDFIRE1, Texture.WILDFIRE1_HOVERED) {
//				public void clickAction() {
//					TSurvival.alertsToRemove.add(wildfireAlert2);
//				}
//			}
//	);
//	
//	public static final MenuSetup wildfireAlert3 = new MenuSetup(
//			new Button(558, 5, 200, 566, Texture.WILDFIRE2, Texture.WILDFIRE2_HOVERED) {
//				public void clickAction() {
//					TSurvival.alertsToRemove.add(wildfireAlert3);
//				}
//			}
//	);
//	
//	public static final MenuSetup wildfireAlert4 = new MenuSetup(
//			new Button(558, 5, 200, 566, Texture.WILDFIRE3, Texture.WILDFIRE3_HOVERED) {
//				public void clickAction() {
//					TSurvival.alertsToRemove.add(wildfireAlert4);
//				}
//			}
//	);
//	public static final MenuSetup wildfireAlert5 = new MenuSetup(
//			new Button(558, 5, 200, 566, Texture.WILDFIRE4, Texture.WILDFIRE4_HOVERED) {
//				public void clickAction() {
//					TSurvival.alertsToRemove.add(wildfireAlert5);
//				}
//			}
//	);
//	
	public static final MenuSetup craftingMenu = new MenuSetup(
			new Button(284, 80, 80, 80, Texture.WEAPON_1_RECIPE, Texture.WEAPON_1_RECIPE_HOVERED) {
				  public void clickAction() {
					if(Inventory.INVENTORY.getItemCount(Wood.WOOD) >= 100 &&
							Inventory.INVENTORY.getItemCount(Metal.METAL) >= 10) {
						Inventory.INVENTORY.addItems(Weapon.WEAPON_ONE, 1);
						Inventory.INVENTORY.addItems(Wood.WOOD, -100);
						Inventory.INVENTORY.addItems(Metal.METAL, -10);
					}
				  }
			  } 
			, new Button(404, 80, 80, 80, Texture.WEAPON_2_RECIPE, Texture.WEAPON_2_RECIPE_HOVERED) { //PLACEHOLDER TEXTURES
				public void clickAction() {
					if(Inventory.INVENTORY.getItemCount(Weapon.WEAPON_ONE) >= 10) {
						Inventory.INVENTORY.addItems(Weapon.WEAPON_TWO, 1);
						Inventory.INVENTORY.addItems(Weapon.WEAPON_ONE, -10);
					}
				}
			}
			, new Button(284, 200, 80, 80, Texture.WEAPON_3_RECIPE, Texture.WEAPON_3_RECIPE_HOVERED) { //PLACEHOLDER TEXTURES
				public void clickAction() {
					if(Inventory.INVENTORY.getItemCount(Weapon.WEAPON_TWO) >= 10) {
						Inventory.INVENTORY.addItems(Weapon.WEAPON_THREE, 1);
						Inventory.INVENTORY.addItems(Weapon.WEAPON_TWO, -10);
					}
				}
			}
			, new Button(404, 200, 80, 80, Texture.LAMP_RECIPE, Texture.LAMP_RECIPE_HOVERED) {
				public void clickAction() {
					if(Inventory.INVENTORY.getItemCount(Metal.METAL) >= 10) {
						World.getCurrentWorld().addEntity(new Entity(Lamp.LAMP, World.viewpoint.getTrueX(), World.viewpoint.getTrueY()));
						World.getCurrentWorld().moveAllEntities();
						Inventory.INVENTORY.addItems(Metal.METAL, -10);
					}
				}
			}
	);
	
	private Set<Button> allThings; //all the buttons
	
	public MenuSetup() {
		allThings = new HashSet<Button>();
	}
	
	public MenuSetup(Button ... buttons) {
		allThings = new HashSet<Button>();
		for(Button t : buttons) allThings.add(t);
	}
	
	public void addMenuComponent(Button t) {
		allThings.add(t);
	}
	
	public void removeMenuComponent(Button t) {
		allThings.remove(t);
	}
	
	//set all buttons that are being hovered over to their hovered textures
	public void setHovered(Point mouseCoords) {
		for(Button b : allThings) b.setHovered(mouseCoords);
	}
	
	public Set<Button> getAllButtons() {
		return allThings;
	}
	
	//click buttons if the mouse is on those buttons
	public void click(Point mouseCoords) {
		for(Button b : allThings) {
			if(b.contains(mouseCoords)) b.clickAction();
		}
	}
	
}
